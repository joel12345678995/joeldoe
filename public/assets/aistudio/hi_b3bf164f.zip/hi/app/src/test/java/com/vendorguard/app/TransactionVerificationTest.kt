package com.vendorguard.app

import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.domain.validator.TransactionValidator
import com.vendorguard.app.domain.validator.ValidationResult
import com.vendorguard.app.domain.verification.MobileMoneyEngine
import org.junit.Assert.*
import org.junit.Test

class TransactionVerificationTest {

    @Test
    fun testTransactionReferenceValidation() {
        // Valid MTN MoMo reference
        val validMtn = TransactionValidator.validateReference("MOM98273618", PaymentProvider.MTN_MOMO)
        assertTrue(validMtn is ValidationResult.Valid)

        // Empty reference
        val emptyRef = TransactionValidator.validateReference("", PaymentProvider.MTN_MOMO)
        assertTrue(emptyRef is ValidationResult.Invalid)

        // Short reference (< 6 chars)
        val shortRef = TransactionValidator.validateReference("TX12", PaymentProvider.AIRTEL_MONEY)
        assertTrue(shortRef is ValidationResult.Invalid)
    }

    @Test
    fun testTransactionAmountValidation() {
        // Minimum UGX 500
        val tooLow = TransactionValidator.validateAmount(100)
        assertTrue(tooLow is ValidationResult.Invalid)

        // Valid amount
        val validAmount = TransactionValidator.validateAmount(50000)
        assertTrue(validAmount is ValidationResult.Valid)

        // Exceeding maximum standard daily limit
        val tooHigh = TransactionValidator.validateAmount(25000000)
        assertTrue(tooHigh is ValidationResult.Invalid)
    }

    @Test
    fun testDemoModeSimulationOutcomes() {
        // Normal transaction in demo mode
        val normalOutcome = MobileMoneyEngine.processVerification(
            vendorId = "test_vendor",
            reference = "MOM9827361",
            amount = 50000,
            provider = PaymentProvider.MTN_MOMO,
            senderPhone = "0772123456",
            details = "Bag of rice",
            isDemoMode = true
        )
        assertEquals(VerificationStatus.DEMO_VERIFIED, normalOutcome.status)
        assertTrue(normalOutcome.transaction.isDemo)
        assertFalse(normalOutcome.isAuthoritative)

        // Simulated reversal scam
        val reversalOutcome = MobileMoneyEngine.processVerification(
            vendorId = "test_vendor",
            reference = "REV-9827361",
            amount = 150000,
            provider = PaymentProvider.AIRTEL_MONEY,
            senderPhone = "0758534923",
            details = "Simulated reversal",
            isDemoMode = true
        )
        assertEquals(VerificationStatus.REVERSED, reversalOutcome.status)
        assertTrue(reversalOutcome.officialRecommendation.contains("DO NOT RELEASE GOODS"))

        // Simulated failure
        val failOutcome = MobileMoneyEngine.processVerification(
            vendorId = "test_vendor",
            reference = "FAIL-00192",
            amount = 20000,
            provider = PaymentProvider.MTN_MOMO,
            senderPhone = "0788112233",
            details = "",
            isDemoMode = true
        )
        assertEquals(VerificationStatus.FAILED, failOutcome.status)
    }

    @Test
    fun testProductionModeMandatoryWarningRule() {
        // In Production Mode without backend telecom gateway credentials:
        // Transactions must NEVER be authoritatively verified from user input alone
        val liveOutcome = MobileMoneyEngine.processVerification(
            vendorId = "live_vendor",
            reference = "10982736154",
            amount = 80000,
            provider = PaymentProvider.MTN_MOMO,
            senderPhone = "0772123456",
            details = "Produce",
            isDemoMode = false
        )
        assertEquals(VerificationStatus.UNVERIFIED, liveOutcome.status)
        assertFalse(liveOutcome.isAuthoritative)
        assertTrue(liveOutcome.officialRecommendation.contains("*165#"))
        assertTrue(liveOutcome.explanation.contains("credentials are not yet connected"))
    }
}
