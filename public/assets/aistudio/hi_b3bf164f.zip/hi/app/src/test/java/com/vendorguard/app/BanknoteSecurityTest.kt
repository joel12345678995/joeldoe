package com.vendorguard.app

import com.vendorguard.app.domain.banknote.*
import org.junit.Assert.*
import org.junit.Test

class BanknoteSecurityTest {

    @Test
    fun testAllDenominationsSpecAvailability() {
        val denoms = listOf(50000, 20000, 10000, 5000, 2000, 1000)
        for (d in denoms) {
            val spec = BanknoteSecurityFeatures.getSpec(d)
            assertEquals(d, spec.denomination)
            assertTrue(spec.dominantColor.isNotBlank())
            assertTrue(spec.securityFeatures.isNotEmpty())
            assertTrue(spec.securityFeatures.any { it.actionType == CheckAction.FEEL })
            assertTrue(spec.securityFeatures.any { it.actionType == CheckAction.LOOK })
        }
    }

    @Test
    fun testFiftyThousandSpecDetails() {
        val spec50k = BanknoteSecurityFeatures.getSpec(50000)
        assertTrue(spec50k.backMotif.contains("Gorilla"))
        assertTrue(spec50k.securityFeatures.any { it.actionType == CheckAction.TILT })
        val tiltCheck = spec50k.securityFeatures.first { it.actionType == CheckAction.TILT }
        assertTrue(tiltCheck.whatToLookFor.contains("green to deep royal blue"))
    }

    @Test
    fun testLowResolutionImageRejection() {
        val decision = BanknoteQualityChecker.evaluateCapture(
            denomination = 50000,
            imageWidth = 320,
            imageHeight = 240,
            averageLuminance = 0.5f
        )
        assertTrue(decision is InspectionDecision.QualityRejected)
        val rejected = decision as InspectionDecision.QualityRejected
        assertTrue(rejected.reason.contains("resolution is too low"))
    }

    @Test
    fun testDarkLightingImageRejection() {
        val decision = BanknoteQualityChecker.evaluateCapture(
            denomination = 20000,
            imageWidth = 1280,
            imageHeight = 720,
            averageLuminance = 0.08f // extremely dark
        )
        assertTrue(decision is InspectionDecision.QualityRejected)
        val rejected = decision as InspectionDecision.QualityRejected
        assertTrue(rejected.reason.contains("Lighting is too dark"))
    }

    @Test
    fun testHonestInconclusiveInspectionResult() {
        // High quality image must produce Inconclusive result (Never fake counterfeit detection)
        val decision = BanknoteQualityChecker.evaluateCapture(
            denomination = 50000,
            imageWidth = 1280,
            imageHeight = 720,
            averageLuminance = 0.55f
        )
        assertTrue(decision is InspectionDecision.Inconclusive)
        val inconclusive = decision as InspectionDecision.Inconclusive
        assertTrue(inconclusive.reason.contains("Inconclusive") || inconclusive.reason.contains("manual touch"))
        assertEquals(5, inconclusive.physicalChecklist.size)
    }
}
