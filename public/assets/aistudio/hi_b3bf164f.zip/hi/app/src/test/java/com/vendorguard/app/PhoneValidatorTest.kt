package com.vendorguard.app

import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.domain.validator.PhoneValidator
import org.junit.Assert.*
import org.junit.Test

class PhoneValidatorTest {

    @Test
    fun testValidMtnUgandaPhone() {
        val phone1 = "0772123456"
        val phone2 = "+256782998877"
        val phone3 = "256760112233"

        assertTrue(PhoneValidator.isValidUgandanPhone(phone1))
        assertTrue(PhoneValidator.isValidUgandanPhone(phone2))
        assertTrue(PhoneValidator.isValidUgandanPhone(phone3))

        assertEquals(PaymentProvider.MTN_MOMO, PhoneValidator.detectProvider(phone1))
        assertEquals(PaymentProvider.MTN_MOMO, PhoneValidator.detectProvider(phone2))
        assertEquals(PaymentProvider.MTN_MOMO, PhoneValidator.detectProvider(phone3))
    }

    @Test
    fun testValidAirtelUgandaPhone() {
        val phone1 = "0701234567"
        val phone2 = "+256758534923" // Master prompt demo number

        assertTrue(PhoneValidator.isValidUgandanPhone(phone1))
        assertTrue(PhoneValidator.isValidUgandanPhone(phone2))

        assertEquals(PaymentProvider.AIRTEL_MONEY, PhoneValidator.detectProvider(phone1))
        assertEquals(PaymentProvider.AIRTEL_MONEY, PhoneValidator.detectProvider(phone2))
    }

    @Test
    fun testInvalidPhones() {
        assertFalse(PhoneValidator.isValidUgandanPhone("0123456789"))
        assertFalse(PhoneValidator.isValidUgandanPhone("12345"))
        assertFalse(PhoneValidator.isValidUgandanPhone("abcdefg"))
        assertNull(PhoneValidator.detectProvider("0888123456"))
    }

    @Test
    fun testPhoneNormalization() {
        assertEquals("0758534923", PhoneValidator.normalizeUgandanPhone("+256758534923"))
        assertEquals("0758534923", PhoneValidator.normalizeUgandanPhone("256758534923"))
        assertEquals("0758534923", PhoneValidator.normalizeUgandanPhone("0758 534 923"))
        assertEquals("+256758534923", PhoneValidator.formatToInternational("0758534923"))
    }
}
