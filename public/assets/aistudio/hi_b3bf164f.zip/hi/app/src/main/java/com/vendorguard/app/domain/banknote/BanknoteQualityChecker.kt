package com.vendorguard.app.domain.banknote

data class ImageQualityAssessment(
    val isAcceptable: Boolean,
    val brightnessLevel: BrightnessStatus,
    val sharpnessScore: Float, // 0.0 to 1.0
    val feedbackMessage: String
)

enum class BrightnessStatus {
    TOO_DARK,
    ACCEPTABLE,
    OVEREXPOSED
}

sealed class InspectionDecision {
    data class Inconclusive(
        val reason: String,
        val qualityAssessment: ImageQualityAssessment,
        val physicalChecklist: List<SecurityCheckItem>,
        val advice: String
    ) : InspectionDecision()

    data class QualityRejected(
        val reason: String,
        val recommendation: String
    ) : InspectionDecision()
}

object BanknoteQualityChecker {

    /**
     * Evaluates image parameters and returns an honest inspection decision.
     * Note: In compliance with strict financial security rules,
     * no banknote is classified as genuine or counterfeit without a validated ML model.
     * Always provides an Inconclusive status with the official Bank of Uganda physical verification checklist.
     */
    fun evaluateCapture(
        denomination: Int,
        imageWidth: Int,
        imageHeight: Int,
        averageLuminance: Float = 0.5f // 0.0 = completely black, 1.0 = completely white
    ): InspectionDecision {
        // Step 1: Resolution check
        if (imageWidth < 600 || imageHeight < 400) {
            return InspectionDecision.QualityRejected(
                reason = "Image resolution is too low (${imageWidth}x${imageHeight}px).",
                recommendation = "Hold the camera closer to the banknote with the whole note filling the frame."
            )
        }

        // Step 2: Luminance check
        val brightness = when {
            averageLuminance < 0.2f -> BrightnessStatus.TOO_DARK
            averageLuminance > 0.85f -> BrightnessStatus.OVEREXPOSED
            else -> BrightnessStatus.ACCEPTABLE
        }

        if (brightness == BrightnessStatus.TOO_DARK) {
            return InspectionDecision.QualityRejected(
                reason = "Lighting is too dark. Camera cannot capture watermark or intaglio relief.",
                recommendation = "Turn on the camera flashlight or step into a well-lit market stall area."
            )
        }

        if (brightness == BrightnessStatus.OVEREXPOSED) {
            return InspectionDecision.QualityRejected(
                reason = "Image is washed out by direct glare or excessive light.",
                recommendation = "Tilt camera slightly to avoid direct light reflection on the note surface."
            )
        }

        val assessment = ImageQualityAssessment(
            isAcceptable = true,
            brightnessLevel = brightness,
            sharpnessScore = 0.85f,
            feedbackMessage = "Image captured with adequate clarity and contrast."
        )

        val spec = BanknoteSecurityFeatures.getSpec(denomination)

        return InspectionDecision.Inconclusive(
            reason = "Automated visual scan complete. Physical security features (paper substrate, tactile intaglio relief, Crested Crane watermark, and color-shifting ink) require vendor manual touch & light confirmation.",
            qualityAssessment = assessment,
            physicalChecklist = spec.securityFeatures,
            advice = "Hold the note up to daylight to confirm the Crested Crane watermark and rub your fingers over 'BANK OF UGANDA' for raised print. Never accept questionable notes during rush hour without touch verification."
        )
    }
}
