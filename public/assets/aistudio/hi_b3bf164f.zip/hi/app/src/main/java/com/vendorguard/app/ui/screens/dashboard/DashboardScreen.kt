package com.vendorguard.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.AlertSeverity
import com.vendorguard.app.data.model.FraudAlert
import com.vendorguard.app.data.model.Transaction
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.navigation.Screen
import com.vendorguard.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "VendorGuard",
                currentMarket = state.vendor?.market ?: "Uganda Markets",
                unreadNotificationCount = state.unreadNotificationCount,
                onNotificationClick = { onNavigate(Screen.Notifications) }
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Vendor Welcome Banner
            item {
                SecurityCard(backgroundColor = NavySurface) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(EmeraldSuccess.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Welcome, ${state.vendor?.fullName ?: "Market Vendor"}",
                                style = MaterialTheme.typography.titleMedium,
                                color = SlateTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = state.vendor?.businessName ?: "Market Security Hub",
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldSuccess,
                                fontSize = 13.sp
                            )
                        }
                        if (state.vendor?.isDemoAccount == true) {
                            Surface(
                                color = MtnYellow.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "DEMO MODE",
                                    color = MtnYellow,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Quick Action Shortcuts Grid (Verify MoMo, Scan Banknote, Report Fraud)
            item {
                Text(
                    text = "Quick Fraud Defense Actions",
                    style = MaterialTheme.typography.titleMedium,
                    color = SlateTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ActionTile(
                        icon = Icons.Default.CheckCircle,
                        title = "Verify MoMo",
                        subtitle = "MTN / Airtel",
                        accentColor = MtnYellow,
                        onClick = { onNavigate(Screen.Verification) },
                        modifier = Modifier.weight(1f)
                    )
                    ActionTile(
                        icon = Icons.Default.CameraAlt,
                        title = "Banknote",
                        subtitle = "Scan & Checks",
                        accentColor = EmeraldSuccess,
                        onClick = { onNavigate(Screen.Banknote) },
                        modifier = Modifier.weight(1f)
                    )
                    ActionTile(
                        icon = Icons.Default.ReportProblem,
                        title = "Report Fraud",
                        subtitle = "Alert Stall Owners",
                        accentColor = CrimsonDanger,
                        onClick = { onNavigate(Screen.Reporting) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Market Fraud Alerts Ticker / Warning Banner
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Active Market Warnings",
                        style = MaterialTheme.typography.titleMedium,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { onNavigate(Screen.Alerts) }) {
                        Text("View All (${state.activeAlerts.size})", color = EmeraldSuccess, fontSize = 12.sp)
                    }
                }

                if (state.activeAlerts.isEmpty()) {
                    SecurityCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = EmeraldSuccess)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "No active fraud incidents currently reported in ${state.vendor?.market ?: "your market"}.",
                                color = SlateTextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    val topAlert = state.activeAlerts.first()
                    SecurityCard(
                        backgroundColor = if (topAlert.severity == AlertSeverity.CRITICAL)
                            CrimsonDanger.copy(alpha = 0.15f) else AmberWarning.copy(alpha = 0.1f),
                        borderColor = if (topAlert.severity == AlertSeverity.CRITICAL)
                            CrimsonDanger else AmberWarning
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (topAlert.severity == AlertSeverity.CRITICAL) CrimsonDanger else AmberWarning,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = topAlert.title,
                                    color = SlateTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = topAlert.description,
                                    color = SlateTextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }

            // Summary Statistics Grid
            item {
                Text(
                    text = "Activity Overview",
                    style = MaterialTheme.typography.titleMedium,
                    color = SlateTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        count = state.totalTransactions.toString(),
                        label = "Total Checks",
                        icon = Icons.Default.Receipt,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        count = state.verifiedCount.toString(),
                        label = "Verified",
                        icon = Icons.Default.Verified,
                        color = EmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        count = state.reportCount.toString(),
                        label = "Reports",
                        icon = Icons.Default.Warning,
                        color = AmberWarning,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Security Tip of the Day
            state.dailySecurityTip?.let { tip ->
                item {
                    SecurityCard(backgroundColor = NavySecondary) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = MtnYellow,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Market Security Rule",
                                color = MtnYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = tip.title,
                            color = SlateTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = tip.summary,
                            color = SlateTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Recent Transactions List
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Recent Transactions",
                        style = MaterialTheme.typography.titleMedium,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { onNavigate(Screen.History) }) {
                        Text("View History", color = EmeraldSuccess, fontSize = 12.sp)
                    }
                }
            }

            if (state.recentTransactions.isEmpty()) {
                item {
                    SecurityCard {
                        Text(
                            text = "No transactions checked yet. Tap 'Verify MoMo' to record and check a transaction.",
                            color = SlateTextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            } else {
                items(state.recentTransactions) { tx ->
                    TransactionItemRow(tx = tx)
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun ActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = SlateTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = SlateTextSecondary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun StatCard(
    count: String,
    label: String,
    icon: ImageVector,
    color: Color = SlateTextPrimary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = count,
                color = color,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = label,
                color = SlateTextSecondary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun TransactionItemRow(
    tx: Transaction,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
    val dateString = dateFormat.format(Date(tx.timestamp))

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tx.reference,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${tx.provider.name.replace("_", " ")}",
                        color = if (tx.provider.name.startsWith("MTN")) MtnYellow else AirtelRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${tx.senderPhone} • $dateString",
                    color = SlateTextSecondary,
                    fontSize = 11.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                UgxCurrencyText(amount = tx.amount, fontSize = 14)
                Spacer(modifier = Modifier.height(4.dp))
                StatusBadge(status = tx.status)
            }
        }
    }
}
