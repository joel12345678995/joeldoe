package com.vendorguard.app.domain.banknote

data class BanknoteSpec(
    val denomination: Int,
    val dominantColor: String,
    val frontMotif: String,
    val backMotif: String,
    val securityFeatures: List<SecurityCheckItem>
)

data class SecurityCheckItem(
    val stepNumber: Int,
    val actionType: CheckAction,
    val title: String,
    val description: String,
    val whatToLookFor: String
)

enum class CheckAction {
    FEEL,
    LOOK,
    TILT,
    UV_LIGHT
}

object BanknoteSecurityFeatures {

    val DENOMINATIONS = listOf(50000, 20000, 10000, 5000, 2000, 1000)

    fun getSpec(denomination: Int): BanknoteSpec {
        return when (denomination) {
            50000 -> BanknoteSpec(
                denomination = 50000,
                dominantColor = "Golden Yellow / Ochre",
                frontMotif = "Uganda Independence Monument & Stride Monument",
                backMotif = "Silverback Mountain Gorillas (Bwindi Impenetrable Forest)",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Raised Intaglio Print",
                        "Rub your fingers across 'BANK OF UGANDA' and the large '50000' numeral.",
                        "Real cotton paper has distinct, tactile rough ridges that cannot be replicated by standard inkjet or laser printers."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Crested Crane Watermark",
                        "Hold the banknote up towards a light source or open sky.",
                        "You must see a clear three-dimensional Crested Crane facing left, with the bright electrotype text '50000' below it."
                    ),
                    SecurityCheckItem(
                        3, CheckAction.TILT,
                        "Optically Variable Ink (OVI)",
                        "Tilt the note forward and backward in natural light.",
                        "The security emblem on the front changes color smoothly from golden-green to deep royal blue. Counterfeits use flat shiny paint that does not shift."
                    ),
                    SecurityCheckItem(
                        4, CheckAction.LOOK,
                        "Windowed Security Thread",
                        "Inspect the metallic ribbon weaving through the paper.",
                        "When held flat, the metallic strip appears in dashes. When held to light, it forms a continuous dark line with micro-printed 'BOU 50000'."
                    ),
                    SecurityCheckItem(
                        5, CheckAction.UV_LIGHT,
                        "Ultraviolet Fluorescence",
                        "Under 365nm UV light torch.",
                        "Security fibers glow bright green and yellow; denomination block shines bright fluorescent green on reverse."
                    )
                )
            )
            20000 -> BanknoteSpec(
                denomination = 20000,
                dominantColor = "Deep Crimson Red / Pink",
                frontMotif = "Centenary Monument (Centenary Park) & Crested Crane",
                backMotif = "Nile River & Source of the Nile / Owen Falls Dam",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Tactile Intaglio Printing",
                        "Feel the 'BANK OF UGANDA' title and the denomination '20000'.",
                        "Crisp raised ridges felt on the paper surface."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Crested Crane Watermark",
                        "Hold up to the light.",
                        "Clear multi-tone Crested Crane with bright '20000' numeral."
                    ),
                    SecurityCheckItem(
                        3, CheckAction.TILT,
                        "Color Shifting Optical Patch",
                        "Tilt the note back and forth.",
                        "The pattern smoothly transitions from magenta/red to olive green."
                    ),
                    SecurityCheckItem(
                        4, CheckAction.LOOK,
                        "Continuous Security Thread",
                        "Hold against light.",
                        "A solid dark vertical thread with readable micro-text 'BOU 20000'."
                    )
                )
            )
            10000 -> BanknoteSpec(
                denomination = 10000,
                dominantColor = "Purple / Violet",
                frontMotif = "Key to the City Monument & Crested Crane",
                backMotif = "Bwindi Gorillas & Banana Plantations",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Raised Print Ridges",
                        "Feel the rough surface texture on portrait and '10000'.",
                        "Authentic intaglio printing with tactile contrast."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Watermark with Denomination",
                        "Hold against daylight.",
                        "Clear Crested Crane with electrotype '10000'."
                    ),
                    SecurityCheckItem(
                        3, CheckAction.TILT,
                        "Spark Holographic Ribbon",
                        "Tilt note under light.",
                        "Shimmering color band with shifting numeric patterns."
                    )
                )
            )
            5000 -> BanknoteSpec(
                denomination = 5000,
                dominantColor = "Olive Green",
                frontMotif = "World War II Memorial Monument & Lake Victoria",
                backMotif = "African Palm Weavers & Queen Elizabeth National Park",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Paper Substrate Feel",
                        "Genuine cotton substrate with high tensile snap.",
                        "Counterfeits made of photocopy paper feel flimsy and limp."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Crested Crane Watermark",
                        "Check watermark area in bright daylight.",
                        "Clear Crane watermark with electrotype '5000'."
                    )
                )
            )
            2000 -> BanknoteSpec(
                denomination = 2000,
                dominantColor = "Cyan / Light Blue",
                frontMotif = "John Speke Monument & Lake Victoria",
                backMotif = "Nile River Birds & Crested Crane",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Embossed Borders",
                        "Tactile marks near edge for visually impaired vendors.",
                        "Distinct tactile bumps on left border."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Watermark & Security Ribbon",
                        "Examine in light.",
                        "Clear Crested Crane and vertical thread."
                    )
                )
            )
            else -> BanknoteSpec(
                denomination = 1000,
                dominantColor = "Brown / Earth Tone",
                frontMotif = "Uganda Peasant Farmer & Agriculture",
                backMotif = "Trucks & Uganda Grain Silos",
                securityFeatures = listOf(
                    SecurityCheckItem(
                        1, CheckAction.FEEL,
                        "Paper Snap & Crispness",
                        "Crisp cotton feel.",
                        "Does not smear when rubbed with damp fingers."
                    ),
                    SecurityCheckItem(
                        2, CheckAction.LOOK,
                        "Crane Watermark",
                        "View against sunlight.",
                        "Visible Crane watermark."
                    )
                )
            )
        }
    }
}
