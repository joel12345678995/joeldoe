package com.vendorguard.app.ui.screens.education

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.SecurityTip
import com.vendorguard.app.data.model.TipCategory
import com.vendorguard.app.data.repository.SecurityTipRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EducationUiState(
    val selectedCategory: TipCategory? = null,
    val tips: List<SecurityTip> = emptyList(),
    val expandedTipId: String? = null
)

class EducationViewModel(
    private val securityTipRepository: SecurityTipRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(EducationUiState())
    val uiState: StateFlow<EducationUiState> = _uiState.asStateFlow()

    init {
        loadTips()
    }

    fun onCategorySelected(category: TipCategory?) {
        _uiState.update { it.copy(selectedCategory = category) }
        loadTips()
    }

    fun toggleExpand(tipId: String) {
        _uiState.update { current ->
            current.copy(
                expandedTipId = if (current.expandedTipId == tipId) null else tipId
            )
        }
    }

    private fun loadTips() {
        viewModelScope.launch {
            val flow = if (_uiState.value.selectedCategory != null) {
                securityTipRepository.getTipsByCategory(_uiState.value.selectedCategory!!)
            } else {
                securityTipRepository.getAllActiveTips()
            }
            flow.collect { list ->
                _uiState.update { it.copy(tips = list) }
            }
        }
    }
}
