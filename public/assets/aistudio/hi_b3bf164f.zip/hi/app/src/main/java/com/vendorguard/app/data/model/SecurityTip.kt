package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TipCategory(val displayName: String) {
    MOBILE_MONEY("Mobile Money Defense"),
    BANKNOTES("UGX Banknote Authentication"),
    GENERAL_TRADING("Market Trading Safety"),
    ACCOUNT_SECURITY("PIN & Account Protection")
}

@Entity(tableName = "security_tips")
data class SecurityTip(
    @PrimaryKey
    val id: String,
    val title: String,
    val category: TipCategory,
    val summary: String,
    val content: String,
    val actionableRules: List<String>,
    val priority: Int = 0,
    val isActive: Boolean = true
)
