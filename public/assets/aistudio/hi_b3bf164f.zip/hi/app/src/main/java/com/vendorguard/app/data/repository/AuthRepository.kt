package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.UserDao
import com.vendorguard.app.data.model.AccountStatus
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.model.UserRole
import com.vendorguard.app.domain.validator.PhoneValidator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(
    private val userDao: UserDao
) {
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    suspend fun login(phoneOrEmail: String, password: String): AuthResult {
        val trimmed = phoneOrEmail.trim()
        if (trimmed.isEmpty() || password.isEmpty()) {
            return AuthResult.Error("Please enter your phone number / email and password.")
        }

        // Demo profile quick check
        val normalized = PhoneValidator.normalizeUgandanPhone(trimmed)
        if (normalized == "0758534923" || trimmed == "katende.market@vendorguard.ug") {
            val demoUser = userDao.getUserByPhone("0758534923") ?: User(
                id = "demo_vendor_01",
                fullName = "Katende Joseph",
                phoneNumber = "0758534923",
                email = "katende.market@vendorguard.ug",
                businessName = "Katende Produce & Grains",
                market = "Owino Market (St. Balikuddembe)",
                district = "Kampala",
                role = UserRole.VENDOR,
                status = AccountStatus.ACTIVE,
                isDemoAccount = true
            ).also { userDao.insertUser(it) }

            _currentUser.value = demoUser
            return AuthResult.Success(demoUser)
        }

        val existingUser = userDao.getUserByPhone(normalized)
        if (existingUser != null) {
            _currentUser.value = existingUser
            return AuthResult.Success(existingUser)
        }

        return AuthResult.Error("No account found with this phone number. Please register first or use the Demo Profile.")
    }

    suspend fun loginAsDemoUser(): AuthResult {
        return login("0758534923", "demo123")
    }

    suspend fun register(
        fullName: String,
        phone: String,
        email: String?,
        businessName: String,
        market: String,
        district: String,
        password: String,
        role: UserRole = UserRole.VENDOR
    ): AuthResult {
        if (fullName.isBlank()) return AuthResult.Error("Full name is required.")
        if (!PhoneValidator.isValidUgandanPhone(phone)) {
            return AuthResult.Error("Please enter a valid Ugandan phone number (MTN or Airtel, 10 digits).")
        }
        if (businessName.isBlank()) return AuthResult.Error("Business or stall name is required.")
        if (market.isBlank()) return AuthResult.Error("Market selection is required.")
        if (district.isBlank()) return AuthResult.Error("District is required.")
        if (password.length < 6) return AuthResult.Error("Password must be at least 6 characters.")

        val normalized = PhoneValidator.normalizeUgandanPhone(phone)
        val existing = userDao.getUserByPhone(normalized)
        if (existing != null) {
            return AuthResult.Error("An account with phone number $normalized already exists. Please login.")
        }

        val newUser = User(
            id = UUID.randomUUID().toString(),
            fullName = fullName.trim(),
            phoneNumber = normalized,
            email = email?.trim(),
            businessName = businessName.trim(),
            market = market,
            district = district,
            role = role,
            status = AccountStatus.ACTIVE,
            isDemoAccount = false
        )

        userDao.insertUser(newUser)
        _currentUser.value = newUser
        return AuthResult.Success(newUser)
    }

    suspend fun updateProfile(
        fullName: String,
        businessName: String,
        market: String,
        district: String
    ): AuthResult {
        val current = _currentUser.value ?: return AuthResult.Error("Not logged in.")
        val updated = current.copy(
            fullName = fullName.trim(),
            businessName = businessName.trim(),
            market = market,
            district = district
        )
        userDao.updateUser(updated)
        _currentUser.value = updated
        return AuthResult.Success(updated)
    }

    fun logout() {
        _currentUser.value = null
    }
}
