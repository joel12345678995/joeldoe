package com.vendorguard.app.data.local.dao

import androidx.room.*
import com.vendorguard.app.data.model.AppNotification
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE vendorId = :vendorId ORDER BY timestamp DESC")
    fun getNotificationsForVendor(vendorId: String): Flow<List<AppNotification>>

    @Query("SELECT COUNT(*) FROM notifications WHERE vendorId = :vendorId AND isRead = 0")
    fun getUnreadCount(vendorId: String): Flow<Int>

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :notificationId")
    suspend fun markAsRead(notificationId: String)

    @Query("UPDATE notifications SET isRead = 1 WHERE vendorId = :vendorId")
    suspend fun markAllAsRead(vendorId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<AppNotification>)

    @Query("DELETE FROM notifications WHERE id = :notificationId")
    suspend fun deleteNotification(notificationId: String)
}
