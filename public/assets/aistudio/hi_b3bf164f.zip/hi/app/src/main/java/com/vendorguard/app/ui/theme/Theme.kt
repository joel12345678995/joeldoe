package com.vendorguard.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldSuccess,
    onPrimary = Color.Black,
    primaryContainer = EmeraldDark,
    onPrimaryContainer = Color.White,
    secondary = MtnYellow,
    onSecondary = Color.Black,
    secondaryContainer = NavySecondary,
    onSecondaryContainer = Color.White,
    tertiary = AmberWarning,
    onTertiary = Color.Black,
    background = NavyBackground,
    onBackground = SlateTextPrimary,
    surface = NavySurface,
    onSurface = SlateTextPrimary,
    surfaceVariant = NavySecondary,
    onSurfaceVariant = SlateTextSecondary,
    error = CrimsonDanger,
    onError = Color.White,
    outline = SlateBorder
)

@Composable
fun VendorGuardTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
