package com.vendorguard.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.UserRole
import com.vendorguard.app.ui.components.SecurityCard
import com.vendorguard.app.ui.components.UgandanMarketDropdown
import com.vendorguard.app.ui.components.VendorGuardTopBar
import com.vendorguard.app.ui.navigation.Screen
import com.vendorguard.app.ui.theme.*

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    onNavigate: (Screen) -> Unit,
    onLogoutSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.isLoggedOut) {
        if (state.isLoggedOut) {
            onLogoutSuccess()
        }
    }

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Vendor Account & Settings",
                currentMarket = state.user?.market,
                unreadNotificationCount = 0,
                onNotificationClick = {}
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Profile Card
            SecurityCard(backgroundColor = NavySurface) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(EmeraldSuccess.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = state.user?.fullName ?: "Vendor",
                            style = MaterialTheme.typography.titleMedium,
                            color = SlateTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = state.user?.businessName ?: "Market Stall",
                            color = EmeraldSuccess,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = state.user?.phoneNumber ?: "07...",
                            color = SlateTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            color = when (state.user?.role) {
                                UserRole.SYSTEM_ADMIN -> CrimsonDanger.copy(alpha = 0.2f)
                                UserRole.MARKET_ADMIN -> AmberWarning.copy(alpha = 0.2f)
                                else -> EmeraldSuccess.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = state.user?.role?.name ?: "VENDOR",
                                color = when (state.user?.role) {
                                    UserRole.SYSTEM_ADMIN -> CrimsonDanger
                                    UserRole.MARKET_ADMIN -> AmberWarning
                                    else -> EmeraldSuccess
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (state.user?.isDemoAccount == true) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = MtnYellow.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "DEMO PROFILE",
                                    color = MtnYellow,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (state.message != null) {
                Text(
                    text = state.message ?: "",
                    color = EmeraldSuccess,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (state.isEditing) {
                // Edit Profile Form
                SecurityCard(backgroundColor = NavySurface) {
                    Text(
                        text = "Edit Stall Information",
                        style = MaterialTheme.typography.titleMedium,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.editFullName,
                        onValueChange = viewModel::onFullNameChanged,
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.editBusinessName,
                        onValueChange = viewModel::onBusinessNameChanged,
                        label = { Text("Business / Stall Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    UgandanMarketDropdown(
                        selectedMarket = state.editSelectedMarket.name,
                        onMarketSelected = viewModel::onMarketSelected,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = viewModel::cancelEditing,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = viewModel::saveProfile,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                OutlinedButton(
                    onClick = viewModel::startEditing,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Stall & Market Information")
                }
            }

            // Quick Section Navigation Links
            Text(
                text = "Vendor Guard Modules",
                style = MaterialTheme.typography.titleMedium,
                color = SlateTextPrimary,
                fontWeight = FontWeight.Bold
            )

            NavigationLinkCard(
                icon = Icons.Default.ReceiptLong,
                title = "Transaction Log",
                subtitle = "View and filter your verified transactions",
                onClick = { onNavigate(Screen.History) }
            )

            NavigationLinkCard(
                icon = Icons.Default.Assignment,
                title = "My Fraud Incident Reports",
                subtitle = "Track review status of reported scams",
                onClick = { onNavigate(Screen.Reporting) }
            )

            NavigationLinkCard(
                icon = Icons.Default.MenuBook,
                title = "Security & Anti-Fraud Education",
                subtitle = "Guides on UGX banknotes and MoMo defenses",
                onClick = { onNavigate(Screen.Education) }
            )

            // Market / System Admin control button (if privileged role or demo admin)
            NavigationLinkCard(
                icon = Icons.Default.AdminPanelSettings,
                title = "Market Committee Admin Panel",
                subtitle = "Moderate fraud reports and publish market alerts",
                iconColor = AmberWarning,
                onClick = { onNavigate(Screen.Admin) }
            )

            // Privacy & Permission Explanations
            SecurityCard(backgroundColor = NavySurface) {
                Text(
                    text = "Privacy & Data Protection Notice",
                    color = EmeraldSuccess,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• VendorGuard only accesses camera hardware when you capture banknote images.\n• Your transaction amounts and customer phone numbers are stored strictly on your device and private backend.\n• Market fraud reports do not disclose your personal identity to other vendors.",
                    color = SlateTextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }

            // Logout Button
            Button(
                onClick = viewModel::logout,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger.copy(alpha = 0.2f))
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, tint = CrimsonDanger)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Out of VendorGuard", color = CrimsonDanger, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun NavigationLinkCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    iconColor: Color = EmeraldSuccess,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = SlateTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = subtitle, color = SlateTextSecondary, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SlateTextSecondary)
        }
    }
}
