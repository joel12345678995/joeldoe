package com.vendorguard.app.domain.validator

import com.vendorguard.app.data.model.PaymentProvider

object PhoneValidator {

    private val MTN_PREFIXES = listOf("077", "078", "076", "039", "031")
    private val AIRTEL_PREFIXES = listOf("070", "075", "074")

    fun isValidUgandanPhone(phone: String): Boolean {
        val normalized = normalizeUgandanPhone(phone)
        return normalized.length == 10 && (MTN_PREFIXES.any { normalized.startsWith(it) } ||
                AIRTEL_PREFIXES.any { normalized.startsWith(it) })
    }

    fun normalizeUgandanPhone(phone: String): String {
        var clean = phone.replace("\\s".toRegex(), "").replace("-", "")
        if (clean.startsWith("+256")) {
            clean = "0" + clean.removePrefix("+256")
        } else if (clean.startsWith("256")) {
            clean = "0" + clean.removePrefix("256")
        }
        return clean
    }

    fun formatToInternational(phone: String): String {
        val normalized = normalizeUgandanPhone(phone)
        return if (normalized.startsWith("0") && normalized.length == 10) {
            "+256" + normalized.substring(1)
        } else {
            phone
        }
    }

    fun detectProvider(phone: String): PaymentProvider? {
        val normalized = normalizeUgandanPhone(phone)
        return when {
            MTN_PREFIXES.any { normalized.startsWith(it) } -> PaymentProvider.MTN_MOMO
            AIRTEL_PREFIXES.any { normalized.startsWith(it) } -> PaymentProvider.AIRTEL_MONEY
            else -> null
        }
    }
}
