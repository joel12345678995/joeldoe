package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.FraudReportDao
import com.vendorguard.app.data.local.dao.NotificationDao
import com.vendorguard.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class FraudReportRepository(
    private val fraudReportDao: FraudReportDao,
    private val notificationDao: NotificationDao
) {
    fun getReportsForVendor(vendorId: String): Flow<List<FraudReport>> =
        fraudReportDao.getReportsForVendor(vendorId)

    fun getAllReports(): Flow<List<FraudReport>> =
        fraudReportDao.getAllReports()

    fun getReportCount(vendorId: String): Flow<Int> =
        fraudReportDao.getReportCount(vendorId)

    suspend fun submitReport(
        vendorId: String,
        reporterName: String,
        category: FraudCategory,
        description: String,
        market: String,
        district: String,
        approxLocation: String,
        transactionReference: String,
        evidenceUri: String? = null
    ): FraudReport {
        val report = FraudReport(
            id = UUID.randomUUID().toString(),
            vendorId = vendorId,
            reporterName = reporterName,
            category = category,
            description = description.trim(),
            market = market,
            district = district,
            approxLocation = approxLocation.trim(),
            transactionReference = transactionReference.trim(),
            evidenceUri = evidenceUri,
            status = ReportStatus.SUBMITTED,
            synced = true
        )

        fraudReportDao.insertReport(report)

        // Notification acknowledging receipt
        notificationDao.insertNotification(
            AppNotification(
                id = UUID.randomUUID().toString(),
                vendorId = vendorId,
                title = "Fraud Report Submitted",
                message = "Your report regarding '${category.displayName}' in $market has been logged for review.",
                type = NotificationType.REPORT,
                referenceId = report.id
            )
        )

        return report
    }

    suspend fun updateReportStatus(reportId: String, status: ReportStatus, adminNotes: String) {
        val report = fraudReportDao.getReportById(reportId) ?: return
        val updated = report.copy(status = status, adminNotes = adminNotes)
        fraudReportDao.updateReport(updated)

        // Notify the vendor of status change
        notificationDao.insertNotification(
            AppNotification(
                id = UUID.randomUUID().toString(),
                vendorId = report.vendorId,
                title = "Fraud Report Status Updated: ${status.name}",
                message = "Your report on ${report.category.displayName} is now ${status.name}. $adminNotes",
                type = NotificationType.REPORT,
                referenceId = reportId
            )
        )
    }
}
