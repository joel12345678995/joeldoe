package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.FraudAlertDao
import com.vendorguard.app.data.local.dao.FraudReportDao
import com.vendorguard.app.data.local.dao.UserDao
import com.vendorguard.app.data.model.*
import kotlinx.coroutines.flow.Flow

data class AdminOverviewStats(
    val totalUsers: Int,
    val totalReports: Int,
    val pendingReviewReports: Int,
    val activeAlerts: Int
)

class AdminRepository(
    private val userDao: UserDao,
    private val fraudReportDao: FraudReportDao,
    private val alertDao: FraudAlertDao
) {
    fun getAllUsers(): Flow<List<User>> = userDao.getAllUsers()

    fun getAllReports(): Flow<List<FraudReport>> = fraudReportDao.getAllReports()

    fun getReportsByStatus(status: ReportStatus): Flow<List<FraudReport>> =
        fraudReportDao.getReportsByStatus(status)

    fun getAllAlerts(): Flow<List<FraudAlert>> = alertDao.getAllActiveAlerts()

    suspend fun updateReportReview(reportId: String, status: ReportStatus, notes: String) {
        val report = fraudReportDao.getReportById(reportId) ?: return
        fraudReportDao.updateReport(report.copy(status = status, adminNotes = notes))
    }

    suspend fun deactivateAlert(alertId: String) {
        alertDao.deactivateAlert(alertId)
    }
}
