package com.vendorguard.app.ui.screens.verification

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.domain.verification.VerificationOutcome
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.theme.*

@Composable
fun VerificationScreen(
    viewModel: VerificationViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Payment Verification",
                currentMarket = state.currentUser?.market,
                unreadNotificationCount = 0,
                onNotificationClick = {}
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Critical Security Notice Card
            SecurityCard(
                backgroundColor = AmberWarning.copy(alpha = 0.12f),
                borderColor = AmberWarning
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.SecurityUpdateWarning,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ANTI-FRAUD MANDATORY NOTICE",
                            color = AmberWarning,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "1. Customer SMS messages and phone screenshots are NOT authoritative proof of payment.\n2. Always verify your own merchant wallet balance via USSD (*165# MTN / *185# Airtel) before handing over goods.",
                            color = SlateTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Demo Mode Switch Card
            SecurityCard(backgroundColor = NavySurface) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Demo / Training Mode",
                                style = MaterialTheme.typography.titleMedium,
                                color = SlateTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (state.isDemoMode) MtnYellow.copy(alpha = 0.2f) else SlateBorder,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (state.isDemoMode) "ACTIVE" else "OFF",
                                    color = if (state.isDemoMode) MtnYellow else SlateTextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = if (state.isDemoMode)
                                "Simulates telecom gateway responses for market vendor training."
                            else
                                "Production Mode: Real telecom API authentication required on server.",
                            color = SlateTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = state.isDemoMode,
                        onCheckedChange = viewModel::onDemoModeToggled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = MtnYellow
                        )
                    )
                }
            }

            // Provider Selection
            Text(
                text = "Select Payment Provider",
                style = MaterialTheme.typography.titleMedium,
                color = SlateTextPrimary,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ProviderSelectorCard(
                    title = "MTN MoMo",
                    subtitle = "*165# USSD",
                    isSelected = state.provider == PaymentProvider.MTN_MOMO,
                    brandColor = MtnYellow,
                    onClick = { viewModel.onProviderSelected(PaymentProvider.MTN_MOMO) },
                    modifier = Modifier.weight(1f)
                )
                ProviderSelectorCard(
                    title = "Airtel Money",
                    subtitle = "*185# USSD",
                    isSelected = state.provider == PaymentProvider.AIRTEL_MONEY,
                    brandColor = AirtelRed,
                    onClick = { viewModel.onProviderSelected(PaymentProvider.AIRTEL_MONEY) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Transaction Details Form
            Text(
                text = "Transaction Details",
                style = MaterialTheme.typography.titleMedium,
                color = SlateTextPrimary,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = state.reference,
                onValueChange = viewModel::onReferenceChanged,
                label = { Text("Transaction Reference / ID (e.g., 1892839218)") },
                leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = SlateTextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldSuccess,
                    unfocusedBorderColor = SlateBorder
                )
            )

            OutlinedTextField(
                value = state.amountText,
                onValueChange = viewModel::onAmountChanged,
                label = { Text("Amount Received (UGX)") },
                leadingIcon = { Icon(Icons.Default.Payments, contentDescription = null, tint = SlateTextSecondary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldSuccess,
                    unfocusedBorderColor = SlateBorder
                )
            )

            OutlinedTextField(
                value = state.senderPhone,
                onValueChange = viewModel::onSenderPhoneChanged,
                label = { Text("Customer Sender Phone (07...)") },
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = SlateTextSecondary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldSuccess,
                    unfocusedBorderColor = SlateBorder
                )
            )

            OutlinedTextField(
                value = state.details,
                onValueChange = viewModel::onDetailsChanged,
                label = { Text("Goods / Notes (e.g., 2 bags of matooke)") },
                leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = SlateTextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldSuccess,
                    unfocusedBorderColor = SlateBorder
                )
            )

            if (state.errorMessage != null) {
                Text(
                    text = state.errorMessage ?: "",
                    color = CrimsonDanger,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Quick Demo Test Case Buttons (for testing simulation scenarios)
            if (state.isDemoMode) {
                Text(
                    text = "Quick Training Scenarios:",
                    color = SlateTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = {
                            viewModel.onReferenceChanged("MOM-9827361")
                            viewModel.onAmountChanged("50000")
                            viewModel.onSenderPhoneChanged("0772123456")
                        },
                        label = { Text("Normal MoMo", fontSize = 11.sp) }
                    )
                    AssistChip(
                        onClick = {
                            viewModel.onReferenceChanged("REV-8273615")
                            viewModel.onAmountChanged("150000")
                            viewModel.onSenderPhoneChanged("0758112233")
                        },
                        label = { Text("Reversal Scam", fontSize = 11.sp, color = CrimsonDanger) }
                    )
                    AssistChip(
                        onClick = {
                            viewModel.onReferenceChanged("FAIL-00123")
                            viewModel.onAmountChanged("25000")
                            viewModel.onSenderPhoneChanged("0701998877")
                        },
                        label = { Text("Failed Tx", fontSize = 11.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = viewModel::executeVerification,
                enabled = !state.isVerifying,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
            ) {
                if (state.isVerifying) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Checking Network Gateway...", color = Color.Black, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isDemoMode) "Run Demo Verification" else "Verify Transaction Authenticity",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Verification Outcome Modal / Dialog
        state.verificationOutcome?.let { outcome ->
            VerificationResultDialog(
                outcome = outcome,
                onDismiss = viewModel::clearOutcome
            )
        }
    }
}

@Composable
fun ProviderSelectorCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    brandColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) brandColor else SlateBorder,
                shape = RoundedCornerShape(10.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) brandColor.copy(alpha = 0.15f) else NavySurface
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = if (isSelected) brandColor else SlateTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                color = SlateTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun VerificationResultDialog(
    outcome: VerificationOutcome,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
            ) {
                Text("Got It", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusBadge(status = outcome.status)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Ref: ${outcome.transaction.reference}",
                    color = SlateTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                UgxCurrencyText(amount = outcome.transaction.amount, fontSize = 18)

                Divider(color = SlateBorder)

                Text(
                    text = "System Explanation:",
                    color = SlateTextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
                Text(
                    text = outcome.explanation,
                    color = SlateTextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Surface(
                    color = NavyBackground,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Vendor Action Guidance:",
                            color = AmberWarning,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = outcome.officialRecommendation,
                            color = SlateTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        },
        containerColor = NavySurface,
        shape = RoundedCornerShape(12.dp)
    )
}
