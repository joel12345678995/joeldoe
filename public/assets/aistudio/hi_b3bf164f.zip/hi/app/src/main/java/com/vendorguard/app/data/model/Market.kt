package com.vendorguard.app.data.model

data class Market(
    val id: String,
    val name: String,
    val district: String,
    val latitude: Double,
    val longitude: Double,
    val vendorCountEstimate: Int = 0
) {
    companion object {
        val DEFAULT_MARKETS = listOf(
            Market("owino", "Owino Market (St. Balikuddembe)", "Kampala", 0.3117, 32.5762, 50000),
            Market("nakasero", "Nakasero Market", "Kampala", 0.3138, 32.5802, 12000),
            Market("kalerwe", "Kalerwe Market", "Kampala", 0.3475, 32.5694, 25000),
            Market("wandegeya", "Wandegeya Market", "Kampala", 0.3340, 32.5690, 8000),
            Market("usafi", "Usafi Market", "Kampala", 0.3060, 32.5720, 6000),
            Market("bwaise", "Bwaise Market", "Kampala", 0.3540, 32.5600, 15000),
            Market("jinja_central", "Jinja Central Market", "Jinja", 0.4244, 33.2041, 18000),
            Market("mbarara_central", "Mbarara Central Market", "Mbarara", -0.6072, 30.6545, 14000),
            Market("gulu_main", "Gulu Main Market", "Gulu", 2.7747, 32.2990, 16000),
            Market("mbale_main", "Mbale Central Market", "Mbale", 1.0784, 34.1755, 12000)
        )
    }
}
