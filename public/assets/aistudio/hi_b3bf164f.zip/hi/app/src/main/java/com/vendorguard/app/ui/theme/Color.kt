package com.vendorguard.app.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0A192F)
val NavySecondary = Color(0xFF172A45)
val NavyLight = Color(0xFF303C55)
val NavyBackground = Color(0xFF060D17)
val NavySurface = Color(0xFF112240)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldLight = Color(0xFFD1FAE5)

val AmberWarning = Color(0xFFF59E0B)
val AmberLight = Color(0xFFFEF3C7)

val CrimsonDanger = Color(0xFFEF4444)
val CrimsonLight = Color(0xFFFEE2E2)

val MtnYellow = Color(0xFFFFCC00)
val AirtelRed = Color(0xFFE50914)

val SlateTextPrimary = Color(0xFFF8FAFC)
val SlateTextSecondary = Color(0xFF94A3B8)
val SlateBorder = Color(0xFF233554)
