package com.vendorguard.app.data.local.dao

import androidx.room.*
import com.vendorguard.app.data.model.FraudReport
import com.vendorguard.app.data.model.ReportStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface FraudReportDao {
    @Query("SELECT * FROM fraud_reports WHERE vendorId = :vendorId ORDER BY timestamp DESC")
    fun getReportsForVendor(vendorId: String): Flow<List<FraudReport>>

    @Query("SELECT * FROM fraud_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<FraudReport>>

    @Query("SELECT * FROM fraud_reports WHERE status = :status ORDER BY timestamp DESC")
    fun getReportsByStatus(status: ReportStatus): Flow<List<FraudReport>>

    @Query("SELECT * FROM fraud_reports WHERE id = :reportId LIMIT 1")
    suspend fun getReportById(reportId: String): FraudReport?

    @Query("SELECT COUNT(*) FROM fraud_reports WHERE vendorId = :vendorId")
    fun getReportCount(vendorId: String): Flow<Int>

    @Query("SELECT * FROM fraud_reports WHERE synced = 0")
    suspend fun getUnsyncedReports(): List<FraudReport>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: FraudReport)

    @Update
    suspend fun updateReport(report: FraudReport)

    @Query("DELETE FROM fraud_reports WHERE id = :reportId")
    suspend fun deleteReport(reportId: String)
}
