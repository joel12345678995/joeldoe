package com.vendorguard.app.ui.screens.education

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.SecurityTip
import com.vendorguard.app.data.model.TipCategory
import com.vendorguard.app.ui.components.EmptyStateView
import com.vendorguard.app.ui.components.VendorGuardTopBar
import com.vendorguard.app.ui.theme.*

@Composable
fun EducationScreen(
    viewModel: EducationViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Security Guide & Education",
                currentMarket = null,
                unreadNotificationCount = 0,
                onNotificationClick = {},
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SlateTextPrimary)
                    }
                }
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = state.selectedCategory == null,
                        onClick = { viewModel.onCategorySelected(null) },
                        label = { Text("All Guidelines", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
                items(TipCategory.values()) { cat ->
                    val isSelected = state.selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onCategorySelected(cat) },
                        label = { Text(cat.displayName, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (state.tips.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.MenuBook,
                    title = "No Guidelines Found",
                    message = "No security guidelines available for this category."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.tips) { tip ->
                        val isExpanded = state.expandedTipId == tip.id
                        EducationTipCard(
                            tip = tip,
                            isExpanded = isExpanded,
                            onToggle = { viewModel.toggleExpand(tip.id) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
fun EducationTipCard(
    tip: SecurityTip,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (icon, color) = when (tip.category) {
        TipCategory.MOBILE_MONEY -> Icons.Default.Payments to MtnYellow
        TipCategory.BANKNOTES -> Icons.Default.MonetizationOn to EmeraldSuccess
        TipCategory.GENERAL_TRADING -> Icons.Default.Storefront to AmberWarning
        TipCategory.ACCOUNT_SECURITY -> Icons.Default.Lock to Color(0xFF38BDF8)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tip.category.displayName,
                        color = color,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = tip.title,
                        color = SlateTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = SlateTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = tip.summary,
                color = SlateTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            if (isExpanded) {
                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = SlateBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = tip.content,
                    color = SlateTextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                if (tip.actionableRules.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Rules to Follow at Your Stall:",
                        color = EmeraldSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    tip.actionableRules.forEach { rule ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text("• ", color = EmeraldSuccess, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(rule, color = SlateTextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }
    }
}
