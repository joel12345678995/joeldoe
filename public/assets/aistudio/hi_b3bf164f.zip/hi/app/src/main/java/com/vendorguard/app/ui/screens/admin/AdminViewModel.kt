package com.vendorguard.app.ui.screens.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.*
import com.vendorguard.app.data.repository.AdminRepository
import com.vendorguard.app.data.repository.AlertRepository
import com.vendorguard.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
    val currentUser: User? = null,
    val isAuthorized: Boolean = false,
    val activeTab: Int = 0, // 0 = Reports Moderation, 1 = Publish Alert, 2 = Users List
    val reports: List<FraudReport> = emptyList(),
    val alerts: List<FraudAlert> = emptyList(),
    val users: List<User> = emptyList(),

    // Publish Alert Form
    val alertTitle: String = "",
    val alertDescription: String = "",
    val alertMarket: Market = Market.DEFAULT_MARKETS[0],
    val alertCategory: FraudCategory = FraudCategory.FAKE_MOMO_SMS,
    val alertSeverity: AlertSeverity = AlertSeverity.HIGH,
    val alertPublishSuccess: Boolean = false,

    val selectedReport: FraudReport? = null,
    val moderationNotes: String = "",
    val message: String? = null
)

class AdminViewModel(
    private val adminRepository: AdminRepository,
    private val alertRepository: AlertRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                val authorized = user != null && (user.role == UserRole.MARKET_ADMIN || user.role == UserRole.SYSTEM_ADMIN || user.isDemoAccount)
                _uiState.update {
                    it.copy(
                        currentUser = user,
                        isAuthorized = authorized
                    )
                }
                if (authorized) {
                    loadAdminData()
                }
            }
        }
    }

    fun onTabSelected(tabIndex: Int) {
        _uiState.update { it.copy(activeTab = tabIndex, message = null) }
    }

    fun onAlertTitleChanged(title: String) {
        _uiState.update { it.copy(alertTitle = title) }
    }

    fun onAlertDescriptionChanged(desc: String) {
        _uiState.update { it.copy(alertDescription = desc) }
    }

    fun onAlertMarketSelected(market: Market) {
        _uiState.update { it.copy(alertMarket = market) }
    }

    fun onAlertCategorySelected(cat: FraudCategory) {
        _uiState.update { it.copy(alertCategory = cat) }
    }

    fun onAlertSeveritySelected(sev: AlertSeverity) {
        _uiState.update { it.copy(alertSeverity = sev) }
    }

    fun onSelectReport(report: FraudReport) {
        _uiState.update { it.copy(selectedReport = report, moderationNotes = report.adminNotes) }
    }

    fun dismissReportDetail() {
        _uiState.update { it.copy(selectedReport = null) }
    }

    fun onModerationNotesChanged(notes: String) {
        _uiState.update { it.copy(moderationNotes = notes) }
    }

    fun updateReportStatus(reportId: String, newStatus: ReportStatus) {
        viewModelScope.launch {
            adminRepository.updateReportReview(
                reportId = reportId,
                status = newStatus,
                notes = _uiState.value.moderationNotes
            )
            _uiState.update {
                it.copy(
                    selectedReport = null,
                    message = "Report status updated to ${newStatus.name}"
                )
            }
        }
    }

    fun publishAlert() {
        val state = _uiState.value
        if (state.alertTitle.isBlank() || state.alertDescription.isBlank()) {
            _uiState.update { it.copy(message = "Title and description are required.") }
            return
        }

        viewModelScope.launch {
            alertRepository.publishAlert(
                title = state.alertTitle,
                description = state.alertDescription,
                market = state.alertMarket.name,
                district = state.alertMarket.district,
                category = state.alertCategory,
                severity = state.alertSeverity,
                publisherId = state.currentUser?.id ?: "admin",
                publisherName = state.currentUser?.fullName ?: "Market Security Admin"
            )

            _uiState.update {
                it.copy(
                    alertTitle = "",
                    alertDescription = "",
                    alertPublishSuccess = true,
                    message = "Market alert published successfully to all vendors in ${state.alertMarket.name}."
                )
            }
        }
    }

    private fun loadAdminData() {
        viewModelScope.launch {
            adminRepository.getAllReports().collect { list ->
                _uiState.update { it.copy(reports = list) }
            }
        }
        viewModelScope.launch {
            adminRepository.getAllAlerts().collect { list ->
                _uiState.update { it.copy(alerts = list) }
            }
        }
        viewModelScope.launch {
            adminRepository.getAllUsers().collect { list ->
                _uiState.update { it.copy(users = list) }
            }
        }
    }
}
