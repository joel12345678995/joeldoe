package com.vendorguard.app.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.Transaction
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.TransactionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HistoryUiState(
    val currentUser: User? = null,
    val searchQuery: String = "",
    val selectedProvider: PaymentProvider? = null,
    val selectedStatus: VerificationStatus? = null,
    val allTransactions: List<Transaction> = emptyList(),
    val filteredTransactions: List<Transaction> = emptyList(),
    val selectedTransaction: Transaction? = null
)

class HistoryViewModel(
    private val transactionRepository: TransactionRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
                val vendorId = user?.id ?: "demo_vendor_01"
                observeTransactions(vendorId)
            }
        }
    }

    private fun observeTransactions(vendorId: String) {
        viewModelScope.launch {
            transactionRepository.getTransactionsForVendor(vendorId).collect { list ->
                _uiState.update { current ->
                    current.copy(
                        allTransactions = list,
                        filteredTransactions = applyFilters(list, current.searchQuery, current.selectedProvider, current.selectedStatus)
                    )
                }
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = query,
                filteredTransactions = applyFilters(current.allTransactions, query, current.selectedProvider, current.selectedStatus)
            )
        }
    }

    fun onProviderFilterSelected(provider: PaymentProvider?) {
        _uiState.update { current ->
            current.copy(
                selectedProvider = provider,
                filteredTransactions = applyFilters(current.allTransactions, current.searchQuery, provider, current.selectedStatus)
            )
        }
    }

    fun onStatusFilterSelected(status: VerificationStatus?) {
        _uiState.update { current ->
            current.copy(
                selectedStatus = status,
                filteredTransactions = applyFilters(current.allTransactions, current.searchQuery, current.selectedProvider, status)
            )
        }
    }

    fun onTransactionClicked(transaction: Transaction) {
        _uiState.update { it.copy(selectedTransaction = transaction) }
    }

    fun dismissDetail() {
        _uiState.update { it.copy(selectedTransaction = null) }
    }

    private fun applyFilters(
        list: List<Transaction>,
        query: String,
        provider: PaymentProvider?,
        status: VerificationStatus?
    ): List<Transaction> {
        return list.filter { tx ->
            val matchesQuery = query.isBlank() ||
                    tx.reference.contains(query, ignoreCase = true) ||
                    tx.senderPhone.contains(query, ignoreCase = true) ||
                    tx.details.contains(query, ignoreCase = true)

            val matchesProvider = provider == null || tx.provider == provider
            val matchesStatus = status == null || tx.status == status

            matchesQuery && matchesProvider && matchesStatus
        }
    }
}
