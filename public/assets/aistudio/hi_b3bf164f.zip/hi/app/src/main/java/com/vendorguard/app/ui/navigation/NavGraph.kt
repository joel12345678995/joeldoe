package com.vendorguard.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.vendorguard.app.VendorGuardApp
import com.vendorguard.app.ui.components.VendorGuardBottomBar
import com.vendorguard.app.ui.screens.admin.AdminScreen
import com.vendorguard.app.ui.screens.admin.AdminViewModel
import com.vendorguard.app.ui.screens.alerts.AlertsScreen
import com.vendorguard.app.ui.screens.alerts.AlertsViewModel
import com.vendorguard.app.ui.screens.auth.AuthScreen
import com.vendorguard.app.ui.screens.auth.AuthViewModel
import com.vendorguard.app.ui.screens.banknote.BanknoteScreen
import com.vendorguard.app.ui.screens.banknote.BanknoteViewModel
import com.vendorguard.app.ui.screens.dashboard.DashboardScreen
import com.vendorguard.app.ui.screens.dashboard.DashboardViewModel
import com.vendorguard.app.ui.screens.education.EducationScreen
import com.vendorguard.app.ui.screens.education.EducationViewModel
import com.vendorguard.app.ui.screens.history.HistoryScreen
import com.vendorguard.app.ui.screens.history.HistoryViewModel
import com.vendorguard.app.ui.screens.notifications.NotificationsScreen
import com.vendorguard.app.ui.screens.notifications.NotificationsViewModel
import com.vendorguard.app.ui.screens.profile.ProfileScreen
import com.vendorguard.app.ui.screens.profile.ProfileViewModel
import com.vendorguard.app.ui.screens.reporting.ReportingScreen
import com.vendorguard.app.ui.screens.reporting.ReportingViewModel
import com.vendorguard.app.ui.screens.verification.VerificationScreen
import com.vendorguard.app.ui.screens.verification.VerificationViewModel

@Composable
fun VendorGuardNavGraph(
    app: VendorGuardApp = VendorGuardApp.instance,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Auth.route

    val currentUser by app.authRepository.currentUser.collectAsState()
    val startDestination = if (currentUser != null) Screen.Dashboard.route else Screen.Auth.route

    val shouldShowBottomBar = currentRoute in Screen.bottomNavItems.map { it.route }

    Scaffold(
        bottomBar = {
            if (shouldShowBottomBar) {
                VendorGuardBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { screen ->
                        navController.navigate(screen.route) {
                            popUpTo(Screen.Dashboard.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Auth.route) {
                val authViewModel = viewModel { AuthViewModel(app.authRepository) }
                AuthScreen(
                    viewModel = authViewModel,
                    onAuthSuccess = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Dashboard.route) {
                val dashboardViewModel = viewModel {
                    DashboardViewModel(
                        app.authRepository,
                        app.transactionRepository,
                        app.fraudReportRepository,
                        app.alertRepository,
                        app.notificationRepository,
                        app.securityTipRepository
                    )
                }
                DashboardScreen(
                    viewModel = dashboardViewModel,
                    onNavigate = { screen -> navController.navigate(screen.route) }
                )
            }

            composable(Screen.Verification.route) {
                val verificationViewModel = viewModel {
                    VerificationViewModel(app.transactionRepository, app.authRepository)
                }
                VerificationScreen(
                    viewModel = verificationViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Banknote.route) {
                val banknoteViewModel = viewModel { BanknoteViewModel() }
                BanknoteScreen(
                    viewModel = banknoteViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Alerts.route) {
                val alertsViewModel = viewModel {
                    AlertsViewModel(app.alertRepository, app.authRepository)
                }
                AlertsScreen(
                    viewModel = alertsViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Notifications.route) {
                val notificationsViewModel = viewModel {
                    NotificationsViewModel(app.notificationRepository, app.authRepository)
                }
                NotificationsScreen(
                    viewModel = notificationsViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Reporting.route) {
                val reportingViewModel = viewModel {
                    ReportingViewModel(app.fraudReportRepository, app.authRepository)
                }
                ReportingScreen(
                    viewModel = reportingViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.History.route) {
                val historyViewModel = viewModel {
                    HistoryViewModel(app.transactionRepository, app.authRepository)
                }
                HistoryScreen(
                    viewModel = historyViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Education.route) {
                val educationViewModel = viewModel {
                    EducationViewModel(app.securityTipRepository)
                }
                EducationScreen(
                    viewModel = educationViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Profile.route) {
                val profileViewModel = viewModel {
                    ProfileViewModel(app.authRepository)
                }
                ProfileScreen(
                    viewModel = profileViewModel,
                    onNavigate = { screen -> navController.navigate(screen.route) },
                    onLogoutSuccess = {
                        navController.navigate(Screen.Auth.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Admin.route) {
                val adminViewModel = viewModel {
                    AdminViewModel(app.adminRepository, app.alertRepository, app.authRepository)
                }
                AdminScreen(
                    viewModel = adminViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
