package com.vendorguard.app.ui.screens.alerts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.AlertSeverity
import com.vendorguard.app.data.model.FraudAlert
import com.vendorguard.app.data.model.Market
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AlertRepository
import com.vendorguard.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AlertsUiState(
    val currentUser: User? = null,
    val selectedMarket: Market = Market.DEFAULT_MARKETS[0],
    val selectedSeverity: AlertSeverity? = null,
    val alerts: List<FraudAlert> = emptyList(),
    val selectedAlert: FraudAlert? = null,
    val isLoading: Boolean = false
)

class AlertsViewModel(
    private val alertRepository: AlertRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AlertsUiState())
    val uiState: StateFlow<AlertsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
                if (user != null) {
                    val matching = Market.DEFAULT_MARKETS.find { it.name == user.market }
                        ?: Market.DEFAULT_MARKETS[0]
                    _uiState.update { it.copy(selectedMarket = matching) }
                    loadAlerts(matching.name)
                } else {
                    loadAlerts(Market.DEFAULT_MARKETS[0].name)
                }
            }
        }
    }

    fun onMarketSelected(market: Market) {
        _uiState.update { it.copy(selectedMarket = market) }
        loadAlerts(market.name)
    }

    fun onSeverityFilterSelected(severity: AlertSeverity?) {
        _uiState.update { it.copy(selectedSeverity = severity) }
        loadAlerts(_uiState.value.selectedMarket.name)
    }

    fun onAlertClicked(alert: FraudAlert) {
        _uiState.update { it.copy(selectedAlert = alert) }
    }

    fun dismissAlertDetail() {
        _uiState.update { it.copy(selectedAlert = null) }
    }

    private fun loadAlerts(marketName: String) {
        viewModelScope.launch {
            alertRepository.getAlertsForMarket(marketName).collect { list ->
                val filtered = if (_uiState.value.selectedSeverity != null) {
                    list.filter { it.severity == _uiState.value.selectedSeverity }
                } else {
                    list
                }
                _uiState.update { it.copy(alerts = filtered) }
            }
        }
    }
}
