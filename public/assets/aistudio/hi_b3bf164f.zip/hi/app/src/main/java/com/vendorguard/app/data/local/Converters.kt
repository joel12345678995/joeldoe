package com.vendorguard.app.data.local

import androidx.room.TypeConverter
import com.vendorguard.app.data.model.*

class Converters {
    @TypeConverter
    fun fromUserRole(value: UserRole?): String? = value?.name
    @TypeConverter
    fun toUserRole(value: String?): UserRole? = value?.let { UserRole.valueOf(it) }

    @TypeConverter
    fun fromAccountStatus(value: AccountStatus?): String? = value?.name
    @TypeConverter
    fun toAccountStatus(value: String?): AccountStatus? = value?.let { AccountStatus.valueOf(it) }

    @TypeConverter
    fun fromPaymentProvider(value: PaymentProvider?): String? = value?.name
    @TypeConverter
    fun toPaymentProvider(value: String?): PaymentProvider? = value?.let { PaymentProvider.valueOf(it) }

    @TypeConverter
    fun fromVerificationStatus(value: VerificationStatus?): String? = value?.name
    @TypeConverter
    fun toVerificationStatus(value: String?): VerificationStatus? = value?.let { VerificationStatus.valueOf(it) }

    @TypeConverter
    fun fromFraudCategory(value: FraudCategory?): String? = value?.name
    @TypeConverter
    fun toFraudCategory(value: String?): FraudCategory? = value?.let { FraudCategory.valueOf(it) }

    @TypeConverter
    fun fromReportStatus(value: ReportStatus?): String? = value?.name
    @TypeConverter
    fun toReportStatus(value: String?): ReportStatus? = value?.let { ReportStatus.valueOf(it) }

    @TypeConverter
    fun fromAlertSeverity(value: AlertSeverity?): String? = value?.name
    @TypeConverter
    fun toAlertSeverity(value: String?): AlertSeverity? = value?.let { AlertSeverity.valueOf(it) }

    @TypeConverter
    fun fromNotificationType(value: NotificationType?): String? = value?.name
    @TypeConverter
    fun toNotificationType(value: String?): NotificationType? = value?.let { NotificationType.valueOf(it) }

    @TypeConverter
    fun fromTipCategory(value: TipCategory?): String? = value?.name
    @TypeConverter
    fun toTipCategory(value: String?): TipCategory? = value?.let { TipCategory.valueOf(it) }

    @TypeConverter
    fun fromStringList(value: List<String>?): String? = value?.joinToString(";;;")
    @TypeConverter
    fun toStringList(value: String?): List<String>? =
        if (value.isNullOrEmpty()) emptyList() else value.split(";;;")
}
