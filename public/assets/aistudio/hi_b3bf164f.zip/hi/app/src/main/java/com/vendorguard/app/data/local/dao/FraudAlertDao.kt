package com.vendorguard.app.data.local.dao

import androidx.room.*
import com.vendorguard.app.data.model.AlertSeverity
import com.vendorguard.app.data.model.FraudAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface FraudAlertDao {
    @Query("SELECT * FROM fraud_alerts WHERE isActive = 1 ORDER BY timestamp DESC")
    fun getAllActiveAlerts(): Flow<List<FraudAlert>>

    @Query("SELECT * FROM fraud_alerts WHERE isActive = 1 AND (market = :market OR market = 'ALL') ORDER BY timestamp DESC")
    fun getAlertsForMarket(market: String): Flow<List<FraudAlert>>

    @Query("SELECT * FROM fraud_alerts WHERE isActive = 1 AND severity = :severity ORDER BY timestamp DESC")
    fun getAlertsBySeverity(severity: AlertSeverity): Flow<List<FraudAlert>>

    @Query("SELECT * FROM fraud_alerts WHERE id = :alertId LIMIT 1")
    suspend fun getAlertById(alertId: String): FraudAlert?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: FraudAlert)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<FraudAlert>)

    @Update
    suspend fun updateAlert(alert: FraudAlert)

    @Query("UPDATE fraud_alerts SET isActive = 0 WHERE id = :alertId")
    suspend fun deactivateAlert(alertId: String)
}
