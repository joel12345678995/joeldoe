package com.vendorguard.app.ui.screens.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.AppNotification
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class NotificationsUiState(
    val currentUser: User? = null,
    val notifications: List<AppNotification> = emptyList(),
    val unreadCount: Int = 0,
    val isLoading: Boolean = false
)

class NotificationsViewModel(
    private val notificationRepository: NotificationRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(NotificationsUiState())
    val uiState: StateFlow<NotificationsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
                val vendorId = user?.id ?: "demo_vendor_01"
                observeNotifications(vendorId)
            }
        }
    }

    private fun observeNotifications(vendorId: String) {
        viewModelScope.launch {
            notificationRepository.getNotificationsForVendor(vendorId).collect { list ->
                _uiState.update { it.copy(notifications = list) }
            }
        }
        viewModelScope.launch {
            notificationRepository.getUnreadCount(vendorId).collect { count ->
                _uiState.update { it.copy(unreadCount = count) }
            }
        }
    }

    fun markAsRead(notificationId: String) {
        viewModelScope.launch {
            notificationRepository.markAsRead(notificationId)
        }
    }

    fun markAllAsRead() {
        val vendorId = _uiState.value.currentUser?.id ?: "demo_vendor_01"
        viewModelScope.launch {
            notificationRepository.markAllAsRead(vendorId)
        }
    }
}
