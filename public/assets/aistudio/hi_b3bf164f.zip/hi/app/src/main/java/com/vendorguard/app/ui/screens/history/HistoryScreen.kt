package com.vendorguard.app.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.Transaction
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Transaction Log",
                currentMarket = state.currentUser?.market,
                unreadNotificationCount = 0,
                onNotificationClick = {},
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SlateTextPrimary)
                    }
                }
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::onSearchQueryChanged,
                placeholder = { Text("Search by Ref, Phone, or Item...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateTextSecondary) },
                trailingIcon = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SlateTextSecondary)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldSuccess,
                    unfocusedBorderColor = SlateBorder
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Provider Filter Chips (All, MTN MoMo, Airtel Money)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = state.selectedProvider == null,
                        onClick = { viewModel.onProviderFilterSelected(null) },
                        label = { Text("All Providers", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
                items(listOf(PaymentProvider.MTN_MOMO, PaymentProvider.AIRTEL_MONEY)) { provider ->
                    val isSelected = state.selectedProvider == provider
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onProviderFilterSelected(provider) },
                        label = { Text(if (provider == PaymentProvider.MTN_MOMO) "MTN MoMo" else "Airtel Money", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (provider == PaymentProvider.MTN_MOMO) MtnYellow else AirtelRed,
                            containerColor = NavySurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Status Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = state.selectedStatus == null,
                        onClick = { viewModel.onStatusFilterSelected(null) },
                        label = { Text("All Statuses", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
                items(VerificationStatus.values()) { status ->
                    val isSelected = state.selectedStatus == status
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onStatusFilterSelected(status) },
                        label = { Text(status.name, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (state.filteredTransactions.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.ReceiptLong,
                    title = "No Transactions Found",
                    message = "No matching records found for the current filter criteria."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.filteredTransactions) { tx ->
                        TransactionDetailCard(
                            tx = tx,
                            onClick = { viewModel.onTransactionClicked(tx) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }

        // Transaction Full Detail Dialog
        state.selectedTransaction?.let { tx ->
            val dateFormat = SimpleDateFormat("EEEE, dd MMM yyyy 'at' HH:mm:ss", Locale.US)
            val fullDate = dateFormat.format(Date(tx.timestamp))

            AlertDialog(
                onDismissRequest = viewModel::dismissDetail,
                confirmButton = {
                    Button(
                        onClick = viewModel::dismissDetail,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                    ) {
                        Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Transaction Details", color = SlateTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        StatusBadge(status = tx.status)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Reference: ${tx.reference}", color = SlateTextPrimary, fontWeight = FontWeight.Bold)
                        UgxCurrencyText(amount = tx.amount, fontSize = 18)
                        Text("Provider: ${tx.provider.name.replace("_", " ")}", color = MtnYellow, fontSize = 12.sp)
                        Text("Customer Phone: ${tx.senderPhone}", color = SlateTextSecondary, fontSize = 12.sp)
                        Text("Date: $fullDate", color = SlateTextSecondary, fontSize = 11.sp)
                        if (tx.details.isNotBlank()) {
                            Text("Notes: ${tx.details}", color = SlateTextPrimary, fontSize = 12.sp)
                        }
                        Divider(color = SlateBorder)
                        Text(
                            text = "Status Explanation: ${tx.statusReason}",
                            color = SlateTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                },
                containerColor = NavySurface,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun TransactionDetailCard(
    tx: Transaction,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
    val dateString = dateFormat.format(Date(tx.timestamp))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tx.reference,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${tx.provider.name.replace("_", " ")}",
                        color = if (tx.provider == PaymentProvider.MTN_MOMO) MtnYellow else AirtelRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${tx.senderPhone} • $dateString",
                    color = SlateTextSecondary,
                    fontSize = 11.sp
                )
                if (tx.details.isNotBlank()) {
                    Text(
                        text = tx.details,
                        color = SlateTextSecondary.copy(alpha = 0.8f),
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                UgxCurrencyText(amount = tx.amount, fontSize = 14)
                Spacer(modifier = Modifier.height(4.dp))
                StatusBadge(status = tx.status)
            }
        }
    }
}
