package com.vendorguard.app.domain.validator

import com.vendorguard.app.data.model.PaymentProvider

sealed class ValidationResult {
    object Valid : ValidationResult()
    data class Invalid(val reason: String) : ValidationResult()
}

object TransactionValidator {

    fun validateReference(reference: String, provider: PaymentProvider): ValidationResult {
        val trimmed = reference.trim()
        if (trimmed.isEmpty()) {
            return ValidationResult.Invalid("Transaction ID/Reference cannot be empty.")
        }
        if (trimmed.length < 6) {
            return ValidationResult.Invalid("Transaction ID is too short (minimum 6 characters).")
        }
        if (trimmed.length > 30) {
            return ValidationResult.Invalid("Transaction ID is excessively long.")
        }

        // Provider specific pattern checks
        return when (provider) {
            PaymentProvider.MTN_MOMO -> {
                // MTN MoMo transaction IDs are typically 10-14 alphanumeric/numeric digits
                if (!trimmed.matches("^[a-zA-Z0-9.-]+$".toRegex())) {
                    ValidationResult.Invalid("MTN MoMo transaction ID contains invalid characters.")
                } else {
                    ValidationResult.Valid
                }
            }
            PaymentProvider.AIRTEL_MONEY -> {
                // Airtel Money IDs are typically 11-14 alphanumeric characters
                if (!trimmed.matches("^[a-zA-Z0-9.-]+$".toRegex())) {
                    ValidationResult.Invalid("Airtel Money transaction ID contains invalid characters.")
                } else {
                    ValidationResult.Valid
                }
            }
            PaymentProvider.CASH -> ValidationResult.Valid
        }
    }

    fun validateAmount(amount: Long): ValidationResult {
        if (amount <= 0) {
            return ValidationResult.Invalid("Amount must be greater than UGX 0.")
        }
        if (amount < 500) {
            return ValidationResult.Invalid("Minimum transaction amount is UGX 500.")
        }
        if (amount > 20_000_000) {
            return ValidationResult.Invalid("Amount exceeds standard Uganda Mobile Money daily limits (UGX 20,000,000).")
        }
        return ValidationResult.Valid
    }
}
