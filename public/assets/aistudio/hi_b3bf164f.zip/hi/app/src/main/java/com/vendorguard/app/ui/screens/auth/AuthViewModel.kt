package com.vendorguard.app.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.Market
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoginMode: Boolean = true,
    val isLoading: Boolean = false,
    val phoneOrEmail: String = "",
    val password: String = "",
    val fullName: String = "",
    val businessName: String = "",
    val selectedMarket: Market = Market.DEFAULT_MARKETS[0],
    val confirmPassword: String = "",
    val acceptedTerms: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val loggedInUser: User? = null
)

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun toggleAuthMode() {
        _uiState.value = _uiState.value.copy(
            isLoginMode = !_uiState.value.isLoginMode,
            errorMessage = null
        )
    }

    fun onPhoneOrEmailChanged(value: String) {
        _uiState.value = _uiState.value.copy(phoneOrEmail = value, errorMessage = null)
    }

    fun onPasswordChanged(value: String) {
        _uiState.value = _uiState.value.copy(password = value, errorMessage = null)
    }

    fun onFullNameChanged(value: String) {
        _uiState.value = _uiState.value.copy(fullName = value, errorMessage = null)
    }

    fun onBusinessNameChanged(value: String) {
        _uiState.value = _uiState.value.copy(businessName = value, errorMessage = null)
    }

    fun onMarketSelected(market: Market) {
        _uiState.value = _uiState.value.copy(selectedMarket = market)
    }

    fun onConfirmPasswordChanged(value: String) {
        _uiState.value = _uiState.value.copy(confirmPassword = value, errorMessage = null)
    }

    fun onTermsAcceptedChanged(accepted: Boolean) {
        _uiState.value = _uiState.value.copy(acceptedTerms = accepted)
    }

    fun submitLogin() {
        val state = _uiState.value
        _uiState.value = state.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.login(state.phoneOrEmail, state.password)
            when (result) {
                is AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        loggedInUser = result.user
                    )
                }
                is AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = result.message
                    )
                }
            }
        }
    }

    fun loginAsDemoUser() {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.loginAsDemoUser()
            when (result) {
                is AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        loggedInUser = result.user
                    )
                }
                is AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = result.message
                    )
                }
            }
        }
    }

    fun submitRegistration() {
        val state = _uiState.value
        if (state.password != state.confirmPassword) {
            _uiState.value = state.copy(errorMessage = "Passwords do not match.")
            return
        }
        if (!state.acceptedTerms) {
            _uiState.value = state.copy(errorMessage = "Please accept the vendor security terms.")
            return
        }

        _uiState.value = state.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.register(
                fullName = state.fullName,
                phone = state.phoneOrEmail,
                email = null,
                businessName = state.businessName,
                market = state.selectedMarket.name,
                district = state.selectedMarket.district,
                password = state.password
            )
            when (result) {
                is AuthResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        loggedInUser = result.user
                    )
                }
                is AuthResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = result.message
                    )
                }
            }
        }
    }
}
