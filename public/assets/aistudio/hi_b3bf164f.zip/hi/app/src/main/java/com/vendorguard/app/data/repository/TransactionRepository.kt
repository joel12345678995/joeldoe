package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.NotificationDao
import com.vendorguard.app.data.local.dao.TransactionDao
import com.vendorguard.app.data.model.*
import com.vendorguard.app.domain.verification.MobileMoneyEngine
import com.vendorguard.app.domain.verification.VerificationOutcome
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class TransactionRepository(
    private val transactionDao: TransactionDao,
    private val notificationDao: NotificationDao
) {
    fun getTransactionsForVendor(vendorId: String): Flow<List<Transaction>> =
        transactionDao.getTransactionsForVendor(vendorId)

    fun getRecentTransactions(vendorId: String, limit: Int = 5): Flow<List<Transaction>> =
        transactionDao.getRecentTransactions(vendorId, limit)

    fun getTransactionCount(vendorId: String): Flow<Int> =
        transactionDao.getTransactionCount(vendorId)

    fun getVerifiedCount(vendorId: String): Flow<Int> =
        transactionDao.getVerifiedCount(vendorId)

    fun getPendingCount(vendorId: String): Flow<Int> =
        transactionDao.getPendingCount(vendorId)

    suspend fun verifyTransaction(
        vendorId: String,
        reference: String,
        amount: Long,
        provider: PaymentProvider,
        senderPhone: String,
        details: String,
        isDemoMode: Boolean
    ): VerificationOutcome {
        val outcome = MobileMoneyEngine.processVerification(
            vendorId = vendorId,
            reference = reference,
            amount = amount,
            provider = provider,
            senderPhone = senderPhone,
            details = details,
            isDemoMode = isDemoMode
        )

        // Save transaction to local Room database
        transactionDao.insertTransaction(outcome.transaction)

        // Generate in-app notification for critical transaction outcomes
        val notification = AppNotification(
            id = UUID.randomUUID().toString(),
            vendorId = vendorId,
            title = when (outcome.status) {
                VerificationStatus.DEMO_VERIFIED -> "Demo Payment Verification Completed"
                VerificationStatus.VERIFIED -> "Payment Verified: UGX $amount"
                VerificationStatus.UNVERIFIED -> "MoMo Check: Manual USSD Check Required"
                VerificationStatus.REVERSED -> "WARNING: Transaction Reversal Detected"
                VerificationStatus.FAILED -> "Payment Verification Failed"
                VerificationStatus.PENDING -> "Payment Pending Confirmation"
            },
            message = outcome.explanation,
            type = NotificationType.TRANSACTION,
            referenceId = outcome.transaction.id
        )
        notificationDao.insertNotification(notification)

        return outcome
    }

    suspend fun getTransactionById(id: String): Transaction? =
        transactionDao.getTransactionById(id)
}
