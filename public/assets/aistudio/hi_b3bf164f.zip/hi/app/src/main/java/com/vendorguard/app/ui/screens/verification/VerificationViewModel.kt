package com.vendorguard.app.ui.screens.verification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.TransactionRepository
import com.vendorguard.app.domain.validator.PhoneValidator
import com.vendorguard.app.domain.verification.VerificationOutcome
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class VerificationUiState(
    val currentUser: User? = null,
    val reference: String = "",
    val amountText: String = "",
    val senderPhone: String = "",
    val provider: PaymentProvider = PaymentProvider.MTN_MOMO,
    val details: String = "",
    val isDemoMode: Boolean = true, // Default to demo mode for safety
    val isVerifying: Boolean = false,
    val verificationOutcome: VerificationOutcome? = null,
    val errorMessage: String? = null
)

class VerificationViewModel(
    private val transactionRepository: TransactionRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VerificationUiState())
    val uiState: StateFlow<VerificationUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
            }
        }
    }

    fun onReferenceChanged(ref: String) {
        _uiState.update { it.copy(reference = ref, errorMessage = null) }
    }

    fun onAmountChanged(amount: String) {
        val filtered = amount.filter { it.isDigit() }
        _uiState.update { it.copy(amountText = filtered, errorMessage = null) }
    }

    fun onSenderPhoneChanged(phone: String) {
        val detected = PhoneValidator.detectProvider(phone)
        _uiState.update { current ->
            current.copy(
                senderPhone = phone,
                provider = detected ?: current.provider,
                errorMessage = null
            )
        }
    }

    fun onProviderSelected(provider: PaymentProvider) {
        _uiState.update { it.copy(provider = provider) }
    }

    fun onDetailsChanged(details: String) {
        _uiState.update { it.copy(details = details) }
    }

    fun onDemoModeToggled(enabled: Boolean) {
        _uiState.update { it.copy(isDemoMode = enabled) }
    }

    fun clearOutcome() {
        _uiState.update { it.copy(verificationOutcome = null) }
    }

    fun executeVerification() {
        val state = _uiState.value
        val amount = state.amountText.toLongOrNull() ?: 0L

        if (state.reference.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter the transaction reference / ID.") }
            return
        }
        if (amount <= 0) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid amount in UGX.") }
            return
        }
        if (state.senderPhone.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter the sender phone number.") }
            return
        }

        _uiState.update { it.copy(isVerifying = true, errorMessage = null, verificationOutcome = null) }

        viewModelScope.launch {
            // Realistic simulation delay for verification check
            delay(1200)

            val vendorId = state.currentUser?.id ?: "demo_vendor_01"
            val outcome = transactionRepository.verifyTransaction(
                vendorId = vendorId,
                reference = state.reference,
                amount = amount,
                provider = state.provider,
                senderPhone = state.senderPhone,
                details = state.details,
                isDemoMode = state.isDemoMode
            )

            _uiState.update {
                it.copy(
                    isVerifying = false,
                    verificationOutcome = outcome
                )
            }
        }
    }
}
