package com.vendorguard.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.vendorguard.app.data.local.dao.*
import com.vendorguard.app.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Transaction::class,
        FraudReport::class,
        FraudAlert::class,
        AppNotification::class,
        SecurityTip::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class VendorGuardDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun fraudReportDao(): FraudReportDao
    abstract fun fraudAlertDao(): FraudAlertDao
    abstract fun notificationDao(): NotificationDao
    abstract fun securityTipDao(): SecurityTipDao

    companion object {
        @Volatile
        private var INSTANCE: VendorGuardDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): VendorGuardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VendorGuardDatabase::class.java,
                    "vendorguard_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(database: VendorGuardDatabase) {
            val tipDao = database.securityTipDao()
            val alertDao = database.fraudAlertDao()
            val userDao = database.userDao()

            // Demo vendor profile (0758534923 as requested in specifications)
            userDao.insertUser(
                User(
                    id = "demo_vendor_01",
                    fullName = "Katende Joseph",
                    phoneNumber = "0758534923",
                    email = "katende.market@vendorguard.ug",
                    businessName = "Katende Produce & Grains",
                    market = "Owino Market (St. Balikuddembe)",
                    district = "Kampala",
                    role = UserRole.VENDOR,
                    status = AccountStatus.ACTIVE,
                    isDemoAccount = true
                )
            )

            // Seed authentic Ugandan Market security tips
            val seedTips = listOf(
                SecurityTip(
                    id = "tip_momo_01",
                    title = "Never Release Goods Based on Customer SMS or Screenshot",
                    category = TipCategory.MOBILE_MONEY,
                    summary = "Scammers spoof sender IDs or show manipulated photos with matching fonts.",
                    content = "Fraudsters in Owino and Kalerwe frequently generate fake SMS alerts that appear under 'MTNMobileMoney' or 'AirtelMoney' headers, or use Android screenshot editors. Always check your own merchant wallet balance or wait for the confirmation message directly on your own terminal phone.",
                    actionableRules = listOf(
                        "Wait for the confirmation message on YOUR OWN phone, not the customer's phone.",
                        "Dial *165# (MTN) or *185# (Airtel) to check your account balance before handing over high-value goods.",
                        "Match the transaction ID with your official USSD statement if amount exceeds UGX 50,000."
                    ),
                    priority = 1
                ),
                SecurityTip(
                    id = "tip_momo_02",
                    title = "The 'Wrong Number' Refund Scam Defense",
                    category = TipCategory.MOBILE_MONEY,
                    summary = "A scammer pretends they accidentally sent money to your phone and demands immediate cash back.",
                    content = "The customer claims: 'I sent you UGX 150,000 by mistake, please refund me in cash or forward it to my other number.' Meanwhile, no money was received, or a fake SMS was sent, or the transaction is already being reversed via telecom customer support.",
                    actionableRules = listOf(
                        "Never hand over cash for an alleged accidental mobile money transfer.",
                        "Direct the customer to call MTN (100) or Airtel (100) for official reversal handling.",
                        "Telecom customer care will execute reversals through verified escrow without cash payouts."
                    ),
                    priority = 2
                ),
                SecurityTip(
                    id = "tip_notes_01",
                    title = "Bank of Uganda UGX 50,000 & 20,000 Note Inspection",
                    category = TipCategory.BANKNOTES,
                    summary = "Examine the Crested Crane watermark, optical variable ink, and windowed thread.",
                    content = "The UGX 50,000 banknote is the most frequently counterfeited denomination in Ugandan markets. Real banknotes are printed on high-grade cotton substrate with distinct tactile raised print on the main portrait and denominations.",
                    actionableRules = listOf(
                        "FEEL: Rub your fingers over 'BANK OF UGANDA' and denomination numbers for raised intaglio print.",
                        "LOOK: Hold the note up to the light to reveal the Crested Crane watermark and electrotype denomination.",
                        "TILT: Tilt the note to watch the security patch shift color smoothly from green to deep blue."
                    ),
                    priority = 3
                ),
                SecurityTip(
                    id = "tip_general_01",
                    title = "Evening Rush Hour & Dim Light Precautions",
                    category = TipCategory.GENERAL_TRADING,
                    summary = "Most counterfeit notes and fake MoMo scams are attempted between 6:00 PM and 8:30 PM.",
                    content = "Fraudsters exploit market closing rush hours, bad lighting, and distracted vendors. Keep a small UV torch or LED torch at your stall to inspect notes received after sunset.",
                    actionableRules = listOf(
                        "Never accept large denominations in unlit corners or in haste.",
                        "Step into bright stall light before accepting notes from unfamiliar buyers.",
                        "Separate notes received during rush hour until properly examined."
                    ),
                    priority = 4
                )
            )
            tipDao.insertTips(seedTips)

            // Seed initial market fraud alerts (clearly labeled as sample training data)
            val seedAlerts = listOf(
                FraudAlert(
                    id = "alert_01",
                    title = "[Training Sample] Fake MTN MoMo SMS Circulating at Owino Stalls",
                    description = "SAMPLE ALERT: Three produce vendors near Gate 4 reported customers showing SMS notifications from forged sender 'MTN-M0M0' (with zeros instead of 'O's). No merchant balance was updated.",
                    market = "Owino Market (St. Balikuddembe)",
                    district = "Kampala",
                    category = FraudCategory.FAKE_MOMO_SMS,
                    severity = AlertSeverity.HIGH,
                    publishedBy = "market_admin_owino",
                    publishedByName = "Owino Security Training Desk"
                ),
                FraudAlert(
                    id = "alert_02",
                    title = "[Training Sample] Bleached Counterfeit UGX 20,000 Notes in Kalerwe",
                    description = "SAMPLE ALERT: Counterfeit notes with smooth paper texture lacking intaglio raised print detected in fish and meat sections. Check the Crested Crane watermark carefully.",
                    market = "Kalerwe Market",
                    district = "Kampala",
                    category = FraudCategory.COUNTERFEIT_BANKNOTE,
                    severity = AlertSeverity.CRITICAL,
                    publishedBy = "market_admin_kalerwe",
                    publishedByName = "Kalerwe Security Training Desk"
                ),
                FraudAlert(
                    id = "alert_03",
                    title = "[Training Sample] Wrong-Number Reversal Claims Alert",
                    description = "SAMPLE ALERT: Individuals approaching vendors claiming erroneous transfer of UGX 80,000 and requesting cash refunds. Official advice: direct all claimants to telecom customer service.",
                    market = "Nakasero Market",
                    district = "Kampala",
                    category = FraudCategory.WRONG_NUMBER_SCAM,
                    severity = AlertSeverity.MEDIUM,
                    publishedBy = "market_admin_nakasero",
                    publishedByName = "Nakasero Security Training Desk"
                )
            )
            alertDao.insertAlerts(seedAlerts)
        }
    }
}
