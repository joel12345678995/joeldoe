package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NotificationType {
    ALERT,
    TRANSACTION,
    REPORT,
    SYSTEM
}

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey
    val id: String,
    val vendorId: String,
    val title: String,
    val message: String,
    val type: NotificationType,
    val referenceId: String = "",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
