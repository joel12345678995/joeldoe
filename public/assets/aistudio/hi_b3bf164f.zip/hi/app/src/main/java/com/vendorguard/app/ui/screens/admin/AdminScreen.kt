package com.vendorguard.app.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.AlertSeverity
import com.vendorguard.app.data.model.FraudCategory
import com.vendorguard.app.data.model.ReportStatus
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.theme.*

@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Market Committee Admin",
                currentMarket = state.currentUser?.market,
                unreadNotificationCount = 0,
                onNotificationClick = {},
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SlateTextPrimary)
                    }
                }
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Navigation Tabs (Moderate Reports, Publish Alert, Registered Vendors)
            TabRow(
                selectedTabIndex = state.activeTab,
                containerColor = NavySecondary,
                contentColor = EmeraldSuccess
            ) {
                Tab(
                    selected = state.activeTab == 0,
                    onClick = { viewModel.onTabSelected(0) },
                    text = { Text("Reports (${state.reports.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = state.activeTab == 1,
                    onClick = { viewModel.onTabSelected(1) },
                    text = { Text("Publish Alert", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = state.activeTab == 2,
                    onClick = { viewModel.onTabSelected(2) },
                    text = { Text("Vendors (${state.users.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }

            if (state.message != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = state.message ?: "",
                    color = EmeraldSuccess,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (state.activeTab) {
                0 -> {
                    // Reports Moderation List
                    if (state.reports.isEmpty()) {
                        EmptyStateView(
                            icon = Icons.Default.AssignmentTurnedIn,
                            title = "No Reports Under Review",
                            message = "No vendor fraud reports logged at this time."
                        )
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(state.reports) { report ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.onSelectReport(report) },
                                    colors = CardDefaults.cardColors(containerColor = NavySurface)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = report.category.displayName,
                                                color = SlateTextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Surface(
                                                color = when (report.status) {
                                                    ReportStatus.SUBMITTED -> AmberWarning.copy(alpha = 0.2f)
                                                    ReportStatus.CONFIRMED -> CrimsonDanger.copy(alpha = 0.2f)
                                                    ReportStatus.RESOLVED -> EmeraldSuccess.copy(alpha = 0.2f)
                                                    else -> SlateBorder
                                                },
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = report.status.name,
                                                    color = when (report.status) {
                                                        ReportStatus.SUBMITTED -> AmberWarning
                                                        ReportStatus.CONFIRMED -> CrimsonDanger
                                                        ReportStatus.RESOLVED -> EmeraldSuccess
                                                        else -> SlateTextSecondary
                                                    },
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "By: ${report.reporterName} • ${report.market}",
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = report.description,
                                            color = SlateTextPrimary,
                                            fontSize = 12.sp,
                                            maxLines = 2
                                        )
                                    }
                                }
                            }
                            item { Spacer(modifier = Modifier.height(24.dp)) }
                        }
                    }
                }
                1 -> {
                    // Publish Market Alert Form
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Broadcast Market Warning Alert",
                            style = MaterialTheme.typography.titleMedium,
                            color = SlateTextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = state.alertTitle,
                            onValueChange = viewModel::onAlertTitleChanged,
                            label = { Text("Alert Headline (e.g., Fake MoMo SMS at Gate 2)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        UgandanMarketDropdown(
                            selectedMarket = state.alertMarket.name,
                            onMarketSelected = viewModel::onAlertMarketSelected,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Severity Picker
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AlertSeverity.values().forEach { sev ->
                                val isSelected = state.alertSeverity == sev
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.onAlertSeveritySelected(sev) },
                                    label = { Text(sev.name, fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = when (sev) {
                                            AlertSeverity.CRITICAL -> CrimsonDanger
                                            AlertSeverity.HIGH -> AmberWarning
                                            else -> EmeraldSuccess
                                        },
                                        containerColor = NavySurface
                                    )
                                )
                            }
                        }

                        OutlinedTextField(
                            value = state.alertDescription,
                            onValueChange = viewModel::onAlertDescriptionChanged,
                            label = { Text("Alert Instructions & Scammer Modus Operandi") },
                            minLines = 4,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = viewModel::publishAlert,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Broadcast Alert to Vendors", color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
                2 -> {
                    // Registered Vendors List
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(state.users) { u ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = NavySurface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(u.fullName, color = SlateTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${u.businessName} • ${u.market}", color = EmeraldSuccess, fontSize = 11.sp)
                                        Text(u.phoneNumber, color = SlateTextSecondary, fontSize = 11.sp)
                                    }
                                    Surface(
                                        color = EmeraldSuccess.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = u.role.name,
                                            color = EmeraldSuccess,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                        item { Spacer(modifier = Modifier.height(24.dp)) }
                    }
                }
            }
        }

        // Report Review & Status Update Dialog
        state.selectedReport?.let { report ->
            AlertDialog(
                onDismissRequest = viewModel::dismissReportDetail,
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { viewModel.updateReportStatus(report.id, ReportStatus.CONFIRMED) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonDanger)
                        ) {
                            Text("Confirm Fraud", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.updateReportStatus(report.id, ReportStatus.RESOLVED) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                        ) {
                            Text("Resolve", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = viewModel::dismissReportDetail) {
                        Text("Cancel", color = SlateTextSecondary)
                    }
                },
                title = {
                    Text("Moderate Report", color = SlateTextPrimary, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Category: ${report.category.displayName}", color = AmberWarning, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Reporter: ${report.reporterName} (${report.market})", color = SlateTextSecondary, fontSize = 12.sp)
                        Text("Description: ${report.description}", color = SlateTextPrimary, fontSize = 12.sp)
                        if (report.transactionReference.isNotBlank()) {
                            Text("Ref: ${report.transactionReference}", color = MtnYellow, fontSize = 11.sp)
                        }
                        Divider(color = SlateBorder)
                        OutlinedTextField(
                            value = state.moderationNotes,
                            onValueChange = viewModel::onModerationNotesChanged,
                            label = { Text("Admin Review Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                containerColor = NavySurface,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
