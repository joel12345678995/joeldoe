package com.vendorguard.app.ui.screens.banknote

import androidx.lifecycle.ViewModel
import com.vendorguard.app.domain.banknote.BanknoteQualityChecker
import com.vendorguard.app.domain.banknote.BanknoteSecurityFeatures
import com.vendorguard.app.domain.banknote.BanknoteSpec
import com.vendorguard.app.domain.banknote.InspectionDecision
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class CameraState {
    IDLE,
    READY_TO_CAPTURE,
    PROCESSING,
    RESULT_DISPLAYED
}

data class BanknoteUiState(
    val selectedDenomination: Int = 50000,
    val cameraState: CameraState = CameraState.READY_TO_CAPTURE,
    val capturedImageUri: String? = null,
    val inspectionDecision: InspectionDecision? = null,
    val currentSpec: BanknoteSpec = BanknoteSecurityFeatures.getSpec(50000),
    val hasCameraPermission: Boolean = false,
    val errorMessage: String? = null
)

class BanknoteViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BanknoteUiState())
    val uiState: StateFlow<BanknoteUiState> = _uiState.asStateFlow()

    fun onDenominationSelected(denomination: Int) {
        _uiState.update {
            it.copy(
                selectedDenomination = denomination,
                currentSpec = BanknoteSecurityFeatures.getSpec(denomination),
                inspectionDecision = null,
                cameraState = CameraState.READY_TO_CAPTURE
            )
        }
    }

    fun onCameraPermissionResult(granted: Boolean) {
        _uiState.update { it.copy(hasCameraPermission = granted) }
    }

    fun onCaptureSimulated(width: Int = 1280, height: Int = 720, luminance: Float = 0.5f) {
        _uiState.update { it.copy(cameraState = CameraState.PROCESSING) }

        // Evaluate image quality and produce honest Inconclusive decision
        val decision = BanknoteQualityChecker.evaluateCapture(
            denomination = _uiState.value.selectedDenomination,
            imageWidth = width,
            imageHeight = height,
            averageLuminance = luminance
        )

        _uiState.update {
            it.copy(
                cameraState = CameraState.RESULT_DISPLAYED,
                inspectionDecision = decision
            )
        }
    }

    fun retake() {
        _uiState.update {
            it.copy(
                cameraState = CameraState.READY_TO_CAPTURE,
                inspectionDecision = null,
                capturedImageUri = null
            )
        }
    }
}
