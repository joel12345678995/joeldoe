package com.vendorguard.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.vendorguard.app.ui.navigation.VendorGuardNavGraph
import com.vendorguard.app.ui.theme.NavyBackground
import com.vendorguard.app.ui.theme.VendorGuardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VendorGuardTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NavyBackground
                ) {
                    VendorGuardNavGraph()
                }
            }
        }
    }
}
