package com.vendorguard.app.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.*
import com.vendorguard.app.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardUiState(
    val vendor: User? = null,
    val totalTransactions: Int = 0,
    val verifiedCount: Int = 0,
    val pendingCount: Int = 0,
    val reportCount: Int = 0,
    val activeAlerts: List<FraudAlert> = emptyList(),
    val recentTransactions: List<Transaction> = emptyList(),
    val dailySecurityTip: SecurityTip? = null,
    val unreadNotificationCount: Int = 0,
    val isLoading: Boolean = false
)

class DashboardViewModel(
    private val authRepository: AuthRepository,
    private val transactionRepository: TransactionRepository,
    private val fraudReportRepository: FraudReportRepository,
    private val alertRepository: AlertRepository,
    private val notificationRepository: NotificationRepository,
    private val securityTipRepository: SecurityTipRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(vendor = user) }
                if (user != null) {
                    observeUserData(user.id, user.market)
                }
            }
        }

        viewModelScope.launch {
            securityTipRepository.getAllActiveTips().collect { tips ->
                _uiState.update { it.copy(dailySecurityTip = tips.firstOrNull()) }
            }
        }
    }

    private fun observeUserData(vendorId: String, market: String) {
        viewModelScope.launch {
            transactionRepository.getTransactionCount(vendorId).collect { count ->
                _uiState.update { it.copy(totalTransactions = count) }
            }
        }

        viewModelScope.launch {
            transactionRepository.getVerifiedCount(vendorId).collect { count ->
                _uiState.update { it.copy(verifiedCount = count) }
            }
        }

        viewModelScope.launch {
            transactionRepository.getPendingCount(vendorId).collect { count ->
                _uiState.update { it.copy(pendingCount = count) }
            }
        }

        viewModelScope.launch {
            fraudReportRepository.getReportCount(vendorId).collect { count ->
                _uiState.update { it.copy(reportCount = count) }
            }
        }

        viewModelScope.launch {
            alertRepository.getAlertsForMarket(market).collect { alerts ->
                _uiState.update { it.copy(activeAlerts = alerts) }
            }
        }

        viewModelScope.launch {
            transactionRepository.getRecentTransactions(vendorId, limit = 4).collect { list ->
                _uiState.update { it.copy(recentTransactions = list) }
            }
        }

        viewModelScope.launch {
            notificationRepository.getUnreadCount(vendorId).collect { unread ->
                _uiState.update { it.copy(unreadNotificationCount = unread) }
            }
        }
    }
}
