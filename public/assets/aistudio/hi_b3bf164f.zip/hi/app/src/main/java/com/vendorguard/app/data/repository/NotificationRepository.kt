package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.NotificationDao
import com.vendorguard.app.data.model.AppNotification
import kotlinx.coroutines.flow.Flow

class NotificationRepository(
    private val notificationDao: NotificationDao
) {
    fun getNotificationsForVendor(vendorId: String): Flow<List<AppNotification>> =
        notificationDao.getNotificationsForVendor(vendorId)

    fun getUnreadCount(vendorId: String): Flow<Int> =
        notificationDao.getUnreadCount(vendorId)

    suspend fun markAsRead(notificationId: String) {
        notificationDao.markAsRead(notificationId)
    }

    suspend fun markAllAsRead(vendorId: String) {
        notificationDao.markAllAsRead(vendorId)
    }

    suspend fun deleteNotification(notificationId: String) {
        notificationDao.deleteNotification(notificationId)
    }
}
