package com.vendorguard.app.ui.screens.alerts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.AlertSeverity
import com.vendorguard.app.data.model.FraudAlert
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlertsScreen(
    viewModel: AlertsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Market Fraud Alerts",
                currentMarket = state.selectedMarket.name,
                unreadNotificationCount = 0,
                onNotificationClick = {}
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Market Switcher Dropdown
            UgandanMarketDropdown(
                selectedMarket = state.selectedMarket.name,
                onMarketSelected = viewModel::onMarketSelected,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Severity Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = state.selectedSeverity == null,
                        onClick = { viewModel.onSeverityFilterSelected(null) },
                        label = { Text("All Alerts", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
                items(AlertSeverity.values()) { severity ->
                    val isSelected = state.selectedSeverity == severity
                    val chipColor = when (severity) {
                        AlertSeverity.CRITICAL -> CrimsonDanger
                        AlertSeverity.HIGH -> AmberWarning
                        AlertSeverity.MEDIUM -> Color(0xFFFBBF24)
                        AlertSeverity.LOW -> EmeraldSuccess
                    }
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onSeverityFilterSelected(severity) },
                        label = { Text(severity.name, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = chipColor,
                            containerColor = NavySurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (state.alerts.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Shield,
                    title = "No Active Alerts in ${state.selectedMarket.name}",
                    message = "No active fraud alerts have been published for this trading center. You can select another market above to check neighboring markets."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.alerts) { alert ->
                        AlertCard(
                            alert = alert,
                            onClick = { viewModel.onAlertClicked(alert) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }

        // Alert Detail Modal
        state.selectedAlert?.let { alert ->
            AlertDialog(
                onDismissRequest = viewModel::dismissAlertDetail,
                confirmButton = {
                    Button(
                        onClick = viewModel::dismissAlertDetail,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                    ) {
                        Text("Understood", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SeverityBadge(severity = alert.severity)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = alert.title,
                            color = SlateTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Market: ${alert.market} (${alert.district})",
                            color = EmeraldSuccess,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Divider(color = SlateBorder)
                        Text(
                            text = alert.description,
                            color = SlateTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                        Text(
                            text = "Issued by: ${alert.publishedByName}",
                            color = SlateTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                },
                containerColor = NavySurface,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun AlertCard(
    alert: FraudAlert,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
    val dateString = dateFormat.format(Date(alert.timestamp))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SeverityBadge(severity = alert.severity)
                Text(
                    text = dateString,
                    color = SlateTextSecondary,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = alert.title,
                color = SlateTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = alert.description,
                color = SlateTextSecondary,
                fontSize = 12.sp,
                maxLines = 2,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Source: ${alert.publishedByName}",
                    color = SlateTextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun SeverityBadge(severity: AlertSeverity) {
    val (color, label) = when (severity) {
        AlertSeverity.CRITICAL -> CrimsonDanger to "CRITICAL ALERT"
        AlertSeverity.HIGH -> AmberWarning to "HIGH WARNING"
        AlertSeverity.MEDIUM -> Color(0xFFFBBF24) to "MEDIUM ALERT"
        AlertSeverity.LOW -> EmeraldSuccess to "INFO NOTICE"
    }

    Surface(
        color = color.copy(alpha = 0.2f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
