package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.SecurityTipDao
import com.vendorguard.app.data.model.SecurityTip
import com.vendorguard.app.data.model.TipCategory
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class SecurityTipRepository(
    private val tipDao: SecurityTipDao
) {
    fun getAllActiveTips(): Flow<List<SecurityTip>> =
        tipDao.getAllActiveTips()

    fun getTipsByCategory(category: TipCategory): Flow<List<SecurityTip>> =
        tipDao.getTipsByCategory(category)

    suspend fun saveTip(
        title: String,
        category: TipCategory,
        summary: String,
        content: String,
        actionableRules: List<String>,
        priority: Int = 0
    ): SecurityTip {
        val tip = SecurityTip(
            id = UUID.randomUUID().toString(),
            title = title.trim(),
            category = category,
            summary = summary.trim(),
            content = content.trim(),
            actionableRules = actionableRules,
            priority = priority
        )
        tipDao.insertTip(tip)
        return tip
    }

    suspend fun deactivateTip(tipId: String) {
        tipDao.deactivateTip(tipId)
    }
}
