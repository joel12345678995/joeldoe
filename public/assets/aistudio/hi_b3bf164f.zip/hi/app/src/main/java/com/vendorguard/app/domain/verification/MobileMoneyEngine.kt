package com.vendorguard.app.domain.verification

import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.Transaction
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.domain.validator.PhoneValidator
import com.vendorguard.app.domain.validator.TransactionValidator
import com.vendorguard.app.domain.validator.ValidationResult
import java.util.UUID

data class VerificationOutcome(
    val status: VerificationStatus,
    val transaction: Transaction,
    val explanation: String,
    val officialRecommendation: String,
    val isAuthoritative: Boolean
)

object MobileMoneyEngine {

    /**
     * Verifies a mobile money transaction.
     * In Production Mode without direct telecom gateway credentials:
     * Transactions cannot be marked authoritative without provider API confirmation.
     * In Demo Mode:
     * Provides an educational simulation with clearly stated demo indicators.
     */
    fun processVerification(
        vendorId: String,
        reference: String,
        amount: Long,
        provider: PaymentProvider,
        senderPhone: String,
        details: String,
        isDemoMode: Boolean
    ): VerificationOutcome {
        val trimmedRef = reference.trim()
        val normalizedPhone = PhoneValidator.normalizeUgandanPhone(senderPhone)

        // Validate basic inputs
        val refValidation = TransactionValidator.validateReference(trimmedRef, provider)
        if (refValidation is ValidationResult.Invalid) {
            val tx = Transaction(
                id = UUID.randomUUID().toString(),
                vendorId = vendorId,
                reference = trimmedRef,
                amount = amount,
                provider = provider,
                senderPhone = normalizedPhone,
                status = VerificationStatus.FAILED,
                statusReason = refValidation.reason,
                details = details,
                isDemo = isDemoMode
            )
            return VerificationOutcome(
                status = VerificationStatus.FAILED,
                transaction = tx,
                explanation = "Validation Failed: ${refValidation.reason}",
                officialRecommendation = "Do not release goods. Ask customer to verify their transaction reference.",
                isAuthoritative = false
            )
        }

        val amountValidation = TransactionValidator.validateAmount(amount)
        if (amountValidation is ValidationResult.Invalid) {
            val tx = Transaction(
                id = UUID.randomUUID().toString(),
                vendorId = vendorId,
                reference = trimmedRef,
                amount = amount,
                provider = provider,
                senderPhone = normalizedPhone,
                status = VerificationStatus.FAILED,
                statusReason = amountValidation.reason,
                details = details,
                isDemo = isDemoMode
            )
            return VerificationOutcome(
                status = VerificationStatus.FAILED,
                transaction = tx,
                explanation = "Amount Invalid: ${amountValidation.reason}",
                officialRecommendation = "Confirm the correct total before proceeding.",
                isAuthoritative = false
            )
        }

        if (isDemoMode) {
            // Educational Demo Mode Simulation
            return simulateDemoVerification(
                vendorId = vendorId,
                reference = trimmedRef,
                amount = amount,
                provider = provider,
                senderPhone = normalizedPhone,
                details = details
            )
        } else {
            // Live Production Verification
            // CRITICAL SECURITY RULE: Without direct telecom API credentials,
            // never mark an unverified client entry as genuinely verified.
            val tx = Transaction(
                id = UUID.randomUUID().toString(),
                vendorId = vendorId,
                reference = trimmedRef,
                amount = amount,
                provider = provider,
                senderPhone = normalizedPhone,
                status = VerificationStatus.UNVERIFIED,
                statusReason = "Requires direct telecom API gateway authentication.",
                details = details,
                isDemo = false
            )

            val ussdCode = when (provider) {
                PaymentProvider.MTN_MOMO -> "*165#"
                PaymentProvider.AIRTEL_MONEY -> "*185#"
                PaymentProvider.CASH -> "N/A"
            }

            return VerificationOutcome(
                status = VerificationStatus.UNVERIFIED,
                transaction = tx,
                explanation = "Live telecom API credentials (MTN MoMo Open API / Airtel Money Gateway) are not yet connected on the backend server. The app cannot authoritatively confirm this payment via external network without telecom credentials.",
                officialRecommendation = "SECURITY ACTION REQUIRED: Do not rely solely on customer's SMS or screenshot. Dial $ussdCode on your vendor phone to verify your account balance and transaction statement directly.",
                isAuthoritative = false
            )
        }
    }

    private fun simulateDemoVerification(
        vendorId: String,
        reference: String,
        amount: Long,
        provider: PaymentProvider,
        senderPhone: String,
        details: String
    ): VerificationOutcome {
        // Controlled simulation cases for vendor training
        val upperRef = reference.uppercase()
        val (status, reason, explanation, recommendation) = when {
            upperRef.contains("REVERSE") || upperRef.startsWith("REV") -> {
                Quadruple(
                    VerificationStatus.REVERSED,
                    "Simulated telecom transaction reversal.",
                    "DEMO ALERT: Transaction marked as REVERSED by simulated telecom core network. Money was pulled back to sender wallet.",
                    "DO NOT RELEASE GOODS. The customer has initiated a reversal or the transaction was recalled."
                )
            }
            upperRef.contains("FAIL") || upperRef.startsWith("ERR") -> {
                Quadruple(
                    VerificationStatus.FAILED,
                    "Simulated transaction failure at telecom switch.",
                    "DEMO ALERT: Simulated payment failed. No funds were debited from sender or credited to merchant.",
                    "Customer must retry payment. Wait for official confirmation before giving goods."
                )
            }
            upperRef.contains("PEND") || upperRef.startsWith("PND") -> {
                Quadruple(
                    VerificationStatus.PENDING,
                    "Simulated telecom processing delay.",
                    "DEMO NOTICE: Transaction is still pending at the network gateway.",
                    "Ask the customer to wait. Confirm on your terminal phone before releasing goods."
                )
            }
            else -> {
                Quadruple(
                    VerificationStatus.DEMO_VERIFIED,
                    "Simulated successful merchant credit in Demo Mode.",
                    "DEMO VERIFIED (TEST MODE ONLY): In a live environment with configured API keys, this would represent an authoritative settlement confirmed by ${provider.name}.",
                    "THIS IS A SIMULATION FOR TRAINING. In a live market, always verify your own wallet balance via USSD."
                )
            }
        }

        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            vendorId = vendorId,
            reference = reference,
            amount = amount,
            provider = provider,
            senderPhone = senderPhone,
            status = status,
            statusReason = reason,
            details = if (details.isNotBlank()) "$details [DEMO]" else "Demo Mode Verification",
            isDemo = true
        )

        return VerificationOutcome(
            status = status,
            transaction = tx,
            explanation = explanation,
            officialRecommendation = recommendation,
            isAuthoritative = false
        )
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
