package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PaymentProvider {
    MTN_MOMO,
    AIRTEL_MONEY,
    CASH
}

enum class VerificationStatus {
    VERIFIED,
    PENDING,
    FAILED,
    REVERSED,
    UNVERIFIED,
    DEMO_VERIFIED
}

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey
    val id: String,
    val vendorId: String,
    val reference: String,
    val amount: Long, // Amount in UGX
    val provider: PaymentProvider,
    val senderPhone: String,
    val status: VerificationStatus,
    val statusReason: String = "",
    val details: String = "",
    val isDemo: Boolean = false,
    val synced: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
