package com.vendorguard.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.Market
import com.vendorguard.app.data.model.VerificationStatus
import com.vendorguard.app.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun StatusBadge(
    status: VerificationStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label, icon) = when (status) {
        VerificationStatus.VERIFIED -> Quadruple(
            EmeraldSuccess.copy(alpha = 0.2f),
            EmeraldSuccess,
            "VERIFIED",
            Icons.Default.CheckCircle
        )
        VerificationStatus.DEMO_VERIFIED -> Quadruple(
            MtnYellow.copy(alpha = 0.2f),
            MtnYellow,
            "DEMO VERIFIED",
            Icons.Default.Verified
        )
        VerificationStatus.PENDING -> Quadruple(
            AmberWarning.copy(alpha = 0.2f),
            AmberWarning,
            "PENDING",
            Icons.Default.HourglassEmpty
        )
        VerificationStatus.REVERSED -> Quadruple(
            CrimsonDanger.copy(alpha = 0.25f),
            CrimsonDanger,
            "REVERSED",
            Icons.Default.Cancel
        )
        VerificationStatus.FAILED -> Quadruple(
            CrimsonDanger.copy(alpha = 0.2f),
            CrimsonDanger,
            "FAILED",
            Icons.Default.Error
        )
        VerificationStatus.UNVERIFIED -> Quadruple(
            SlateBorder,
            SlateTextSecondary,
            "UNVERIFIED",
            Icons.Default.HelpOutline
        )
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun UgxCurrencyText(
    amount: Long,
    modifier: Modifier = Modifier,
    color: Color = SlateTextPrimary,
    fontSize: Int = 16,
    fontWeight: FontWeight = FontWeight.Bold
) {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    val formatted = formatter.format(amount)
    Text(
        text = "UGX $formatted",
        modifier = modifier,
        color = color,
        fontSize = fontSize.sp,
        fontWeight = fontWeight
    )
}

@Composable
fun SecurityCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = NavySurface,
    borderColor: Color = SlateBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    message: String,
    actionButtonText: String? = null,
    onActionClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = SlateTextSecondary,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = SlateTextPrimary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = SlateTextSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        if (actionButtonText != null && onActionClick != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onActionClick,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
            ) {
                Text(text = actionButtonText, color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UgandanMarketDropdown(
    selectedMarket: String,
    onMarketSelected: (Market) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val markets = Market.DEFAULT_MARKETS

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selectedMarket,
            onValueChange = {},
            readOnly = true,
            label = { Text("Market / Trading Centre") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = EmeraldSuccess,
                unfocusedBorderColor = SlateBorder
            ),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            markets.forEach { market ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(market.name, fontWeight = FontWeight.SemiBold)
                            Text(market.district, fontSize = 12.sp, color = SlateTextSecondary)
                        }
                    },
                    onClick = {
                        onMarketSelected(market)
                        expanded = false
                    }
                )
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
