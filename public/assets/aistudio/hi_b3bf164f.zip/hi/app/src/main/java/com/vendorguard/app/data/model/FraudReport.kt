package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FraudCategory(val displayName: String) {
    FAKE_MOMO_SMS("Fake Mobile Money SMS"),
    COUNTERFEIT_BANKNOTE("Counterfeit Banknote"),
    WRONG_NUMBER_SCAM("Wrong-Number Refund Scam"),
    REVERSED_TRANSACTION("Unauthorized Transaction Reversal"),
    SUSPICIOUS_SCREENSHOT("Manipulated Payment Screenshot"),
    OTHER("Other Suspicious Financial Activity")
}

enum class ReportStatus {
    SUBMITTED,
    UNDER_REVIEW,
    CONFIRMED,
    REJECTED,
    RESOLVED
}

@Entity(tableName = "fraud_reports")
data class FraudReport(
    @PrimaryKey
    val id: String,
    val vendorId: String,
    val reporterName: String = "",
    val category: FraudCategory,
    val description: String,
    val market: String,
    val district: String,
    val approxLocation: String = "",
    val transactionReference: String = "",
    val evidenceUri: String? = null,
    val status: ReportStatus = ReportStatus.SUBMITTED,
    val adminNotes: String = "",
    val synced: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
