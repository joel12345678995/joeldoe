package com.vendorguard.app.ui.screens.banknote

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.domain.banknote.CheckAction
import com.vendorguard.app.domain.banknote.InspectionDecision
import com.vendorguard.app.domain.banknote.SecurityCheckItem
import com.vendorguard.app.ui.components.SecurityCard
import com.vendorguard.app.ui.components.VendorGuardTopBar
import com.vendorguard.app.ui.theme.*

@Composable
fun BanknoteScreen(
    viewModel: BanknoteViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val denominations = listOf(50000, 20000, 10000, 5000, 2000, 1000)

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Banknote Camera Inspection",
                currentMarket = null,
                unreadNotificationCount = 0,
                onNotificationClick = {}
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Denomination Selector Chips
            Text(
                text = "Select UGX Denomination to Inspect",
                style = MaterialTheme.typography.titleMedium,
                color = SlateTextPrimary,
                fontWeight = FontWeight.Bold
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(denominations) { denom ->
                    val isSelected = state.selectedDenomination == denom
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.onDenominationSelected(denom) },
                        label = {
                            Text(
                                text = "UGX ${denom / 1000}K",
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.Black else SlateTextPrimary
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldSuccess,
                            containerColor = NavySurface
                        )
                    )
                }
            }

            if (state.inspectionDecision == null) {
                // Live CameraX Viewfinder & Capture View
                BanknoteCameraView(
                    denomination = state.selectedDenomination,
                    onCapture = { width, height, luminance ->
                        viewModel.onCaptureSimulated(width, height, luminance)
                    }
                )

                // Official Denomination Specs Summary
                SecurityCard(backgroundColor = NavySurface) {
                    Text(
                        text = "Bank of Uganda Official Specification",
                        color = MtnYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Denomination: UGX ${state.selectedDenomination}",
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Dominant Color: ${state.currentSpec.dominantColor}",
                        color = SlateTextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Front: ${state.currentSpec.frontMotif}",
                        color = SlateTextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Reverse: ${state.currentSpec.backMotif}",
                        color = SlateTextSecondary,
                        fontSize = 12.sp
                    )
                }
            } else {
                // Honest Inspection Decision View
                when (val decision = state.inspectionDecision) {
                    is InspectionDecision.Inconclusive -> {
                        // Prominent Inconclusive Warning Badge
                        SecurityCard(
                            backgroundColor = AmberWarning.copy(alpha = 0.15f),
                            borderColor = AmberWarning
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = AmberWarning,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "INCONCLUSIVE – FURTHER VERIFICATION REQUIRED",
                                        color = AmberWarning,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "Standard image processing cannot verify tactile cotton substrate or security thread intaglio.",
                                        color = SlateTextPrimary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        // Quality Checks Summary
                        SecurityCard(backgroundColor = NavySurface) {
                            Text(
                                text = "Image Clarity Assessment",
                                color = SlateTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Status: ${decision.qualityAssessment.feedbackMessage}",
                                color = EmeraldSuccess,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Brightness: ${decision.qualityAssessment.brightnessLevel.name}",
                                color = SlateTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        // Physical Security Verification Checklist
                        Text(
                            text = "Mandatory Physical Inspection Steps",
                            style = MaterialTheme.typography.titleMedium,
                            color = SlateTextPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        decision.physicalChecklist.forEach { item ->
                            PhysicalChecklistCard(item = item)
                        }

                        // Retake button
                        Button(
                            onClick = viewModel::retake,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Retake & Scan Another Note", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                    is InspectionDecision.QualityRejected -> {
                        SecurityCard(
                            backgroundColor = CrimsonDanger.copy(alpha = 0.15f),
                            borderColor = CrimsonDanger
                        ) {
                            Text(
                                text = "Image Quality Rejected",
                                color = CrimsonDanger,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = decision.reason, color = SlateTextPrimary, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = decision.recommendation, color = AmberWarning, fontSize = 11.sp)
                        }
                        Button(
                            onClick = viewModel::retake,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                        ) {
                            Text("Try Again", color = Color.Black)
                        }
                    }
                    null -> {}
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PhysicalChecklistCard(item: SecurityCheckItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            val (icon, color) = when (item.actionType) {
                CheckAction.FEEL -> Icons.Default.TouchApp to MtnYellow
                CheckAction.LOOK -> Icons.Default.Visibility to EmeraldSuccess
                CheckAction.TILT -> Icons.Default.ScreenRotation to AmberWarning
                CheckAction.UV_LIGHT -> Icons.Default.FlashOn to Color(0xFF818CF8)
            }
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "STEP ${item.stepNumber}: ${item.actionType.name}",
                        color = color,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${item.title}",
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = item.description, color = SlateTextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Key Indicator: ${item.whatToLookFor}",
                    color = EmeraldSuccess,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
