package com.vendorguard.app

import android.app.Application
import com.vendorguard.app.data.local.VendorGuardDatabase
import com.vendorguard.app.data.repository.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VendorGuardApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { VendorGuardDatabase.getDatabase(this, applicationScope) }

    val authRepository by lazy { AuthRepository(database.userDao()) }
    val transactionRepository by lazy { TransactionRepository(database.transactionDao(), database.notificationDao()) }
    val fraudReportRepository by lazy { FraudReportRepository(database.fraudReportDao(), database.notificationDao()) }
    val alertRepository by lazy { AlertRepository(database.fraudAlertDao(), database.notificationDao()) }
    val notificationRepository by lazy { NotificationRepository(database.notificationDao()) }
    val securityTipRepository by lazy { SecurityTipRepository(database.securityTipDao()) }
    val adminRepository by lazy { AdminRepository(database.userDao(), database.fraudReportDao(), database.fraudAlertDao()) }
    val offlineSyncManager by lazy { com.vendorguard.app.data.sync.OfflineSyncManager(database.transactionDao(), database.fraudReportDao()) }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Prepopulate database with initial demo data if empty
        applicationScope.launch {
            VendorGuardDatabase.populateInitialData(database)
        }
    }

    companion object {
        lateinit var instance: VendorGuardApp
            private set
    }
}
