package com.vendorguard.app.ui.screens.reporting

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.FraudCategory
import com.vendorguard.app.data.model.FraudReport
import com.vendorguard.app.data.model.Market
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.FraudReportRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ReportingUiState(
    val currentUser: User? = null,
    val selectedCategory: FraudCategory = FraudCategory.FAKE_MOMO_SMS,
    val description: String = "",
    val selectedMarket: Market = Market.DEFAULT_MARKETS[0],
    val approxLocation: String = "",
    val transactionReference: String = "",
    val evidenceNote: String = "",
    val isSubmitting: Boolean = false,
    val isSuccess: Boolean = false,
    val errorMessage: String? = null,
    val vendorReports: List<FraudReport> = emptyList(),
    val showHistoryTab: Boolean = false
)

class ReportingViewModel(
    private val fraudReportRepository: FraudReportRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportingUiState())
    val uiState: StateFlow<ReportingUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { it.copy(currentUser = user) }
                if (user != null) {
                    val matchingMarket = Market.DEFAULT_MARKETS.find { it.name == user.market }
                        ?: Market.DEFAULT_MARKETS[0]
                    _uiState.update { it.copy(selectedMarket = matchingMarket) }
                    observeReports(user.id)
                }
            }
        }
    }

    private fun observeReports(vendorId: String) {
        viewModelScope.launch {
            fraudReportRepository.getReportsForVendor(vendorId).collect { list ->
                _uiState.update { it.copy(vendorReports = list) }
            }
        }
    }

    fun onCategorySelected(category: FraudCategory) {
        _uiState.update { it.copy(selectedCategory = category, errorMessage = null) }
    }

    fun onDescriptionChanged(desc: String) {
        _uiState.update { it.copy(description = desc, errorMessage = null) }
    }

    fun onMarketSelected(market: Market) {
        _uiState.update { it.copy(selectedMarket = market) }
    }

    fun onApproxLocationChanged(loc: String) {
        _uiState.update { it.copy(approxLocation = loc) }
    }

    fun onTransactionReferenceChanged(ref: String) {
        _uiState.update { it.copy(transactionReference = ref) }
    }

    fun onToggleTab(showHistory: Boolean) {
        _uiState.update { it.copy(showHistoryTab = showHistory) }
    }

    fun resetSuccess() {
        _uiState.update { it.copy(isSuccess = false) }
    }

    fun submitReport() {
        val state = _uiState.value
        if (state.description.trim().length < 10) {
            _uiState.update { it.copy(errorMessage = "Please provide a clear description (at least 10 characters).") }
            return
        }

        _uiState.update { it.copy(isSubmitting = true, errorMessage = null) }

        viewModelScope.launch {
            val vendorId = state.currentUser?.id ?: "demo_vendor_01"
            val reporterName = state.currentUser?.fullName ?: "Anonymous Vendor"

            fraudReportRepository.submitReport(
                vendorId = vendorId,
                reporterName = reporterName,
                category = state.selectedCategory,
                description = state.description,
                market = state.selectedMarket.name,
                district = state.selectedMarket.district,
                approxLocation = state.approxLocation,
                transactionReference = state.transactionReference
            )

            _uiState.update {
                it.copy(
                    isSubmitting = false,
                    isSuccess = true,
                    description = "",
                    transactionReference = "",
                    approxLocation = ""
                )
            }
        }
    }
}
