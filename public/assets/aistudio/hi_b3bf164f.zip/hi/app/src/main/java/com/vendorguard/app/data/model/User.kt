package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    VENDOR,
    MARKET_ADMIN,
    SYSTEM_ADMIN
}

enum class AccountStatus {
    ACTIVE,
    PENDING_VERIFICATION,
    SUSPENDED
}

@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val id: String,
    val fullName: String,
    val phoneNumber: String,
    val email: String? = null,
    val businessName: String,
    val market: String,
    val district: String,
    val role: UserRole = UserRole.VENDOR,
    val status: AccountStatus = AccountStatus.ACTIVE,
    val isDemoAccount: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
