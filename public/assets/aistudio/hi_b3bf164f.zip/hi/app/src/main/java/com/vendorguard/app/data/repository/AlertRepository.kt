package com.vendorguard.app.data.repository

import com.vendorguard.app.data.local.dao.FraudAlertDao
import com.vendorguard.app.data.local.dao.NotificationDao
import com.vendorguard.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AlertRepository(
    private val alertDao: FraudAlertDao,
    private val notificationDao: NotificationDao
) {
    fun getAllActiveAlerts(): Flow<List<FraudAlert>> =
        alertDao.getAllActiveAlerts()

    fun getAlertsForMarket(market: String): Flow<List<FraudAlert>> =
        alertDao.getAlertsForMarket(market)

    fun getAlertsBySeverity(severity: AlertSeverity): Flow<List<FraudAlert>> =
        alertDao.getAlertsBySeverity(severity)

    suspend fun publishAlert(
        title: String,
        description: String,
        market: String,
        district: String,
        category: FraudCategory,
        severity: AlertSeverity,
        publisherId: String,
        publisherName: String,
        durationDays: Int = 7
    ): FraudAlert {
        val alert = FraudAlert(
            id = UUID.randomUUID().toString(),
            title = title.trim(),
            description = description.trim(),
            market = market,
            district = district,
            category = category,
            severity = severity,
            publishedBy = publisherId,
            publishedByName = publisherName,
            expiryTimestamp = System.currentTimeMillis() + (durationDays.toLong() * 24 * 60 * 60 * 1000)
        )

        alertDao.insertAlert(alert)

        // Broadcast notification to all active vendors in this market
        notificationDao.insertNotification(
            AppNotification(
                id = UUID.randomUUID().toString(),
                vendorId = "ALL", // Broadcast
                title = "🚨 [${severity.name}] Alert: $title",
                message = "$market: $description",
                type = NotificationType.ALERT,
                referenceId = alert.id
            )
        )

        return alert
    }

    suspend fun deactivateAlert(alertId: String) {
        alertDao.deactivateAlert(alertId)
    }
}
