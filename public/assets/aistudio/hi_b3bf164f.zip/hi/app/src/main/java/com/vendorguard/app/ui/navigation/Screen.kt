package com.vendorguard.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector? = null,
    val unselectedIcon: ImageVector? = null
) {
    object Auth : Screen("auth", "Sign In")
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard)
    object Verification : Screen("verification", "Verify MoMo", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle)
    object Banknote : Screen("banknote", "Banknote Scan", Icons.Filled.CameraAlt, Icons.Outlined.CameraAlt)
    object Alerts : Screen("alerts", "Fraud Alerts", Icons.Filled.Warning, Icons.Outlined.Warning)
    object Notifications : Screen("notifications", "Notifications", Icons.Filled.Notifications, Icons.Outlined.Notifications)
    object Reporting : Screen("reporting", "Report Fraud", Icons.Filled.ReportProblem, Icons.Outlined.ReportProblem)
    object History : Screen("history", "History", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong)
    object Education : Screen("education", "Security Tips", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    object Profile : Screen("profile", "Vendor Profile", Icons.Filled.Person, Icons.Outlined.Person)
    object Admin : Screen("admin", "Admin Control", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings)

    companion object {
        val bottomNavItems = listOf(
            Dashboard,
            Verification,
            Banknote,
            Alerts,
            Profile
        )
    }
}
