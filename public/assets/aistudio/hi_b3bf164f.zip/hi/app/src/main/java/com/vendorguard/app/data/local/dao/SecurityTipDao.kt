package com.vendorguard.app.data.local.dao

import androidx.room.*
import com.vendorguard.app.data.model.SecurityTip
import com.vendorguard.app.data.model.TipCategory
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityTipDao {
    @Query("SELECT * FROM security_tips WHERE isActive = 1 ORDER BY priority ASC")
    fun getAllActiveTips(): Flow<List<SecurityTip>>

    @Query("SELECT * FROM security_tips WHERE isActive = 1 AND category = :category ORDER BY priority ASC")
    fun getTipsByCategory(category: TipCategory): Flow<List<SecurityTip>>

    @Query("SELECT * FROM security_tips WHERE id = :tipId LIMIT 1")
    suspend fun getTipById(tipId: String): SecurityTip?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTip(tip: SecurityTip)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTips(tips: List<SecurityTip>)

    @Update
    suspend fun updateTip(tip: SecurityTip)

    @Query("UPDATE security_tips SET isActive = 0 WHERE id = :tipId")
    suspend fun deactivateTip(tipId: String)
}
