package com.vendorguard.app.ui.screens.reporting

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vendorguard.app.data.model.FraudCategory
import com.vendorguard.app.data.model.FraudReport
import com.vendorguard.app.data.model.ReportStatus
import com.vendorguard.app.ui.components.*
import com.vendorguard.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportingScreen(
    viewModel: ReportingViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            VendorGuardTopBar(
                title = "Report Market Fraud",
                currentMarket = state.selectedMarket.name,
                unreadNotificationCount = 0,
                onNotificationClick = {}
            )
        },
        containerColor = NavyBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Sub-Navigation Tabs: New Report vs My Submitted Reports
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(NavySecondary)
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { viewModel.onToggleTab(false) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!state.showHistoryTab) EmeraldSuccess else Color.Transparent
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "Submit New Report",
                        color = if (!state.showHistoryTab) Color.Black else SlateTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                Button(
                    onClick = { viewModel.onToggleTab(true) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.showHistoryTab) EmeraldSuccess else Color.Transparent
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "My Reports (${state.vendorReports.size})",
                        color = if (state.showHistoryTab) Color.Black else SlateTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (state.showHistoryTab) {
                // Submitted Reports History
                if (state.vendorReports.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.Assignment,
                        title = "No Reports Submitted Yet",
                        message = "You have not submitted any fraud reports. All incidents you log will appear here with review status.",
                        actionButtonText = "Submit Incident",
                        onActionClick = { viewModel.onToggleTab(false) }
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(state.vendorReports) { report ->
                            ReportItemCard(report = report)
                        }
                    }
                }
            } else {
                // New Report Form
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Category Picker
                    Text(
                        text = "Fraud Incident Category",
                        style = MaterialTheme.typography.titleMedium,
                        color = SlateTextPrimary,
                        fontWeight = FontWeight.Bold
                    )

                    var categoryMenuExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = categoryMenuExpanded,
                        onExpandedChange = { categoryMenuExpanded = !categoryMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = state.selectedCategory.displayName,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldSuccess,
                                unfocusedBorderColor = SlateBorder
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = categoryMenuExpanded,
                            onDismissRequest = { categoryMenuExpanded = false }
                        ) {
                            FraudCategory.values().forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.displayName) },
                                    onClick = {
                                        viewModel.onCategorySelected(cat)
                                        categoryMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Market Selector
                    UgandanMarketDropdown(
                        selectedMarket = state.selectedMarket.name,
                        onMarketSelected = viewModel::onMarketSelected,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = state.approxLocation,
                        onValueChange = viewModel::onApproxLocationChanged,
                        label = { Text("Stall / Gate Location (e.g., Gate 3, Produce Row)") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = SlateTextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldSuccess,
                            unfocusedBorderColor = SlateBorder
                        )
                    )

                    OutlinedTextField(
                        value = state.transactionReference,
                        onValueChange = viewModel::onTransactionReferenceChanged,
                        label = { Text("Transaction Reference (if applicable)") },
                        leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = SlateTextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldSuccess,
                            unfocusedBorderColor = SlateBorder
                        )
                    )

                    OutlinedTextField(
                        value = state.description,
                        onValueChange = viewModel::onDescriptionChanged,
                        label = { Text("Incident Description & Scammer Behavior") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldSuccess,
                            unfocusedBorderColor = SlateBorder
                        )
                    )

                    if (state.errorMessage != null) {
                        Text(
                            text = state.errorMessage ?: "",
                            color = CrimsonDanger,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Success Feedback Dialog
                    if (state.isSuccess) {
                        AlertDialog(
                            onDismissRequest = viewModel::resetSuccess,
                            confirmButton = {
                                Button(
                                    onClick = {
                                        viewModel.resetSuccess()
                                        viewModel.onToggleTab(true)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                                ) {
                                    Text("View My Reports", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            },
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Report Received", color = SlateTextPrimary)
                                }
                            },
                            text = {
                                Text(
                                    "Your fraud report has been submitted securely to the Market Security Committee. It will be reviewed to protect other vendors.",
                                    color = SlateTextSecondary,
                                    fontSize = 13.sp
                                )
                            },
                            containerColor = NavySurface
                        )
                    }

                    Button(
                        onClick = viewModel::submitReport,
                        enabled = !state.isSubmitting,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (state.isSubmitting) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Submit Incident Report", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun ReportItemCard(report: FraudReport) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US)
    val dateString = dateFormat.format(Date(report.timestamp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = NavySurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = report.category.displayName,
                    color = SlateTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Surface(
                    color = when (report.status) {
                        ReportStatus.SUBMITTED -> AmberWarning.copy(alpha = 0.2f)
                        ReportStatus.UNDER_REVIEW -> Color(0xFF38BDF8).copy(alpha = 0.2f)
                        ReportStatus.CONFIRMED -> CrimsonDanger.copy(alpha = 0.2f)
                        ReportStatus.RESOLVED -> EmeraldSuccess.copy(alpha = 0.2f)
                        ReportStatus.REJECTED -> SlateBorder
                    },
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = report.status.name,
                        color = when (report.status) {
                            ReportStatus.SUBMITTED -> AmberWarning
                            ReportStatus.UNDER_REVIEW -> Color(0xFF38BDF8)
                            ReportStatus.CONFIRMED -> CrimsonDanger
                            ReportStatus.RESOLVED -> EmeraldSuccess
                            ReportStatus.REJECTED -> SlateTextSecondary
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${report.market} • $dateString",
                color = SlateTextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = report.description,
                color = SlateTextPrimary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
            if (report.transactionReference.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Ref: ${report.transactionReference}",
                    color = MtnYellow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (report.adminNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = NavyBackground,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Admin Note: ${report.adminNotes}",
                        color = SlateTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}
