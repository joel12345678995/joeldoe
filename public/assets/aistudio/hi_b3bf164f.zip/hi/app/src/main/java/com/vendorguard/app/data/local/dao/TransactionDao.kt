package com.vendorguard.app.data.local.dao

import androidx.room.*
import com.vendorguard.app.data.model.PaymentProvider
import com.vendorguard.app.data.model.Transaction
import com.vendorguard.app.data.model.VerificationStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE vendorId = :vendorId ORDER BY timestamp DESC")
    fun getTransactionsForVendor(vendorId: String): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE vendorId = :vendorId ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentTransactions(vendorId: String, limit: Int = 5): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE id = :transactionId LIMIT 1")
    suspend fun getTransactionById(transactionId: String): Transaction?

    @Query("SELECT * FROM transactions WHERE reference = :reference LIMIT 1")
    suspend fun getTransactionByReference(reference: String): Transaction?

    @Query("SELECT * FROM transactions WHERE vendorId = :vendorId AND status = :status ORDER BY timestamp DESC")
    fun getTransactionsByStatus(vendorId: String, status: VerificationStatus): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE vendorId = :vendorId AND provider = :provider ORDER BY timestamp DESC")
    fun getTransactionsByProvider(vendorId: String, provider: PaymentProvider): Flow<List<Transaction>>

    @Query("SELECT COUNT(*) FROM transactions WHERE vendorId = :vendorId")
    fun getTransactionCount(vendorId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM transactions WHERE vendorId = :vendorId AND (status = 'VERIFIED' OR status = 'DEMO_VERIFIED')")
    fun getVerifiedCount(vendorId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM transactions WHERE vendorId = :vendorId AND status = 'PENDING'")
    fun getPendingCount(vendorId: String): Flow<Int>

    @Query("SELECT * FROM transactions WHERE synced = 0")
    suspend fun getUnsyncedTransactions(): List<Transaction>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<Transaction>)

    @Update
    suspend fun updateTransaction(transaction: Transaction)

    @Query("DELETE FROM transactions WHERE id = :transactionId")
    suspend fun deleteTransaction(transactionId: String)
}
