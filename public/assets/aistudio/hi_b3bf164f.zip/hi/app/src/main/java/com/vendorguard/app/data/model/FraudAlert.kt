package com.vendorguard.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AlertSeverity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

@Entity(tableName = "fraud_alerts")
data class FraudAlert(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val market: String,
    val district: String,
    val category: FraudCategory,
    val severity: AlertSeverity,
    val publishedBy: String,
    val publishedByName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val expiryTimestamp: Long = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000), // 7 days default
    val isActive: Boolean = true
)
