package com.vendorguard.app.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vendorguard.app.data.model.Market
import com.vendorguard.app.data.model.User
import com.vendorguard.app.data.repository.AuthRepository
import com.vendorguard.app.data.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val user: User? = null,
    val isEditing: Boolean = false,
    val editFullName: String = "",
    val editBusinessName: String = "",
    val editSelectedMarket: Market = Market.DEFAULT_MARKETS[0],
    val message: String? = null,
    val isLoggedOut: Boolean = false
)

class ProfileViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            authRepository.currentUser.collect { user ->
                _uiState.update { current ->
                    current.copy(
                        user = user,
                        editFullName = user?.fullName ?: "",
                        editBusinessName = user?.businessName ?: "",
                        editSelectedMarket = Market.DEFAULT_MARKETS.find { it.name == user?.market }
                            ?: Market.DEFAULT_MARKETS[0]
                    )
                }
            }
        }
    }

    fun startEditing() {
        val user = _uiState.value.user ?: return
        _uiState.update {
            it.copy(
                isEditing = true,
                editFullName = user.fullName,
                editBusinessName = user.businessName,
                editSelectedMarket = Market.DEFAULT_MARKETS.find { m -> m.name == user.market }
                    ?: Market.DEFAULT_MARKETS[0],
                message = null
            )
        }
    }

    fun cancelEditing() {
        _uiState.update { it.copy(isEditing = false, message = null) }
    }

    fun onFullNameChanged(name: String) {
        _uiState.update { it.copy(editFullName = name) }
    }

    fun onBusinessNameChanged(bName: String) {
        _uiState.update { it.copy(editBusinessName = bName) }
    }

    fun onMarketSelected(market: Market) {
        _uiState.update { it.copy(editSelectedMarket = market) }
    }

    fun saveProfile() {
        val state = _uiState.value
        viewModelScope.launch {
            val result = authRepository.updateProfile(
                fullName = state.editFullName,
                businessName = state.editBusinessName,
                market = state.editSelectedMarket.name,
                district = state.editSelectedMarket.district
            )
            when (result) {
                is AuthResult.Success -> {
                    _uiState.update { it.copy(isEditing = false, message = "Profile updated successfully.") }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(message = result.message) }
                }
            }
        }
    }

    fun logout() {
        authRepository.logout()
        _uiState.update { it.copy(isLoggedOut = true) }
    }
}
